import sys, numpy as np, model_v2 as M
npz = sys.argv[1]; ls = float(sys.argv[2])
for vb in map(float, sys.argv[3:]):
    c = M.prepare(npz, load_scale=ls, vband=vb); nd = M.net_data(c)
    K = len(c["eva_buses"]); xf = np.zeros((K, 24)); xf[:, c["W"]] = 0.5
    for meth in ["DET", "SAA_CVaR"]:
        sol, log = M.solve(c, meth, M.default_pars(threads=8, time_limit=60), x_fixed=xf, log_fn=lambda s: None)
        ev = M.summarize(M.evaluate(c, sol, "test"))
        v = np.sqrt(sol["vsq"][1:])
        print(f"{npz} x{ls} band ±{vb}: {meth:8s} Vmin_nom {v.min():.4f} sec {sol['sec_slack']:.4f} cnet {sol.get('cnet_true',0):.5f} "
              f"DG {sol['pdg'].sum():.2f} econ {sol['econ']:.0f} | p_net {ev['p_net']:.3f} p_res {ev['p_res']:.2f} undel {ev['undel_kWh']:.0f} kWh "
              f"iters {len(log['it'])} t {log['time_s']:.0f}s", flush=True)
