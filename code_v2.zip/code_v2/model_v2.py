"""
model_v2.py -- corrected decision-dependent DRCC scheduling of EV aggregators
(revision for Energy).  Replaces code/ddrcc_model.py; the original is untouched.

What changed with respect to code/ddrcc_model.py (see AUDIT_before_revision.md)
--------------------------------------------------------------------------
1. Signed-margin losses.  Every chance-constraint loss is the signed margin
   (negative = inside the limit), not a non-negative violation magnitude, so a
   CVaR constraint can be met with a positive margin and the radius acts.
2. One ambiguity set, used consistently: type-infinity Wasserstein (W_inf)
   balls with a per-coordinate (box) ground norm, one block for renewable
   errors and one for EV availability.  For W_inf the worst-case CVaR equals
   the sample CVaR of the per-atom worst-case losses, so no dual multiplier
   (and no lambda*pi product) appears.
3. Direction-specific price response.  At price ratio pi = 1 + x (x >= 0) the
   share of connected EVs willing to charge is c(x) = 1 - S_ch x and the share
   willing to discharge (V2G) is d(x) = chi + S_dis x.  The availability error
   xi is price-independent (physical connection uncertainty); the price enters
   only through c and d.
4. Decision-dependent ambiguity for the behavioural block: the image of the
   availability ball under the uncertain response map, S in [S(1-b), S(1+b)].
   Prop. 2 of the revision gives its exact worst-case CVaR for the (monotone)
   reserve-adequacy loss; Prop. 1 (outer ball with moving centre and
   price-dependent radius) is implemented as method "Proposed_P1".
5. Renewable errors: generation sign fixed (a generation surplus raises the
   voltage) and scenarios clipped to the physical output range [0, capacity].
6. Valid decomposition: the CVaR is taken over ALL training days; pieces of the
   max-type losses are generated lazily.  The master is a relaxation (valid LB =
   MIP bound); the exact evaluation of the master solution gives a valid UB.
   The number of pieces is finite, so the loop terminates finitely.
7. Price co-optimisation: x_{k,t} in [0, x_max] in the DR window, with the
   incentive payment C_inc = rho_inc * a P (chi x + S_dis x^2) (convex).  The
   only product of decisions is u*x (binary x bounded), linearised exactly.
"""
import os
import time
import numpy as np

os.environ.setdefault("GRB_LICENSE_FILE", "/Users/dishimin/gurobi.lic")
import gurobipy as gp                                      # noqa: E402
from gurobipy import GRB                                   # noqa: E402
from caseio import load_case, build_RX, downstream_sets, radial_tree  # noqa: E402

PI0 = 1.0
TAU = 0.05            # reserve dead band (fraction of EVA rating), master and evaluation
C_SEC = 1e4           # $/p.u. nominal security slack (effectively hard)
C_NET = 1e6           # $/p.u.^2 network-CC slack (effectively hard)
C_RES = 1e5           # $/MW reserve-CC slack (effectively hard)
LAMBDA_RT = 1000.0    # $/MWh real-time penalty for undelivered reserve (evaluation only)

# dd: how the reserve range depends on price  (blind | nominal | robust | outer)
# risk: none | cvar | moment | robust ;  ball: W_inf radius eps > 0 used
SPEC = {
    "DET":         dict(dd="blind",   risk="none",   ball=False),
    "SAA_CVaR":    dict(dd="blind",   risk="cvar",   ball=False),
    "Moment_DRO":  dict(dd="blind",   risk="moment", ball=False),
    "Exo_Winf":    dict(dd="blind",   risk="cvar",   ball=True),
    "Robust_DDU":  dict(dd="nominal", risk="robust", ball=False),
    "DD_CVaR":     dict(dd="nominal", risk="cvar",   ball=False),
    "Proposed":    dict(dd="robust",  risk="cvar",   ball=True),
    "Proposed_P1": dict(dd="outer",   risk="cvar",   ball=True),
}
METHODS = list(SPEC)


def default_pars(**kw):
    p = dict(alpha=0.05, eps=0.0, beta=0.4, x_max=0.5, rho_inc=20.0,
             mipgap=5e-3, time_limit=120, max_iter=40, tol_rel=5e-3, n_add=3,
             threads=0, verbose=False)
    p.update(kw)
    return p


# ---------------------------------------------------------------------------
# case preparation (physical renewable support, response model, truth draws)
# ---------------------------------------------------------------------------
def prepare(npz, S_ch=0.30, S_dis=0.40, chi=0.5, dc_max=0.25, dd_max=0.25,
            het=0.4, seed=2026, load_scale=1.0, vband=None, ntrain=None, allhours=False, cdeg=None):
    c = load_case(npz)
    if cdeg is not None:                        # degradation-cost sensitivity
        c["Cdeg"] = float(cdeg)
    if ntrain is not None:                      # data-size study: first ntrain training days
        for k_ in ("xi_pv_train", "xi_wt_train", "xi_ev_train"):
            c[k_] = c[k_][:ntrain]
    if vband is not None:                       # MV planning band (headroom for LV feeders)
        c["Vmin"], c["Vmax"] = 1.0 - vband, 1.0 + vband
    if load_scale != 1.0:                       # feeder loading (substation limit scales with it)
        c["P_load"] = c["P_load"] * load_scale; c["Q_load"] = c["Q_load"] * load_scale
        c["Smax_sub"] = c["Smax_sub"] * load_scale
    for split in ("train", "valid", "test"):
        fc = c["PV_fc"][None]; cap = c["pv_cap"][None, :, None]
        c[f"xi_pv_{split}"] = np.clip(c[f"xi_pv_{split}"], -fc, cap - fc)
        fc = c["WT_fc"][None]; cap = c["wt_cap"][None, :, None]
        c[f"xi_wt_{split}"] = np.clip(c[f"xi_wt_{split}"], -fc, cap - fc)
        c[f"xi_ev_{split}"] = c[f"xi_ev_{split}"].astype(float)
    K = len(c["eva_buses"])
    rng = np.random.default_rng(seed)
    c["m_valid"] = rng.uniform(1 - het, 1 + het, size=(c["xi_ev_valid"].shape[0], K))
    c["m_test"] = rng.uniform(1 - het, 1 + het, size=(c["xi_ev_test"].shape[0], K))
    c.update(S_ch=S_ch, S_dis=S_dis, chi=chi, dc_max=dc_max, dd_max=dd_max, het=het)
    c["W"] = np.asarray(c["peak_window"], int) - 1                 # DR window (0-based)
    if allhours:                                                    # price can be set in every hour
        c["W"] = np.arange(int(c["T"]))
    return c


def true_factors(c, x, m):
    """True (saturating, heterogeneous) willingness shares.  x:(K,T), m:(N,K)."""
    xx = x[None]; mm = m[:, :, None]
    ct = 1.0 - mm * c["dc_max"] * np.tanh(c["S_ch"] * xx / c["dc_max"])
    dt = c["chi"] + mm * c["dd_max"] * np.tanh(c["S_dis"] * xx / c["dd_max"])
    return np.clip(ct, 0, 1), np.clip(dt, 0, 1)


def net_data(c):
    nb, SB = int(c["nbus"]), c["SBASE"]
    R, _ = build_RX(c["branches"], nb)
    Rm = R[1:nb + 1, 1:nb + 1]
    ubus = np.concatenate([c["pv_buses"], c["wt_buses"]]).astype(int)
    cap_u = np.concatenate([c["pv_cap"], c["wt_cap"]])
    fc_u = np.concatenate([c["PV_fc"], c["WT_fc"]], axis=0)
    Ru = 2.0 / SB * Rm[:, ubus - 1]                               # (nb,U) dv per MW gen
    Rk = 2.0 / SB * Rm[:, np.asarray(c["eva_buses"], int) - 1]    # (nb,K) dv per MW EV
    down = downstream_sets(c["branches"], nb)
    D = np.zeros((nb - 1, nb))
    for e in range(nb - 1):
        for b in down[e]:
            D[e, b - 1] = 1.0
    return dict(Rm=Rm, Ru=Ru, Rk=Rk, cap_u=cap_u, fc_u=fc_u, D=D)


def xi_re(c, split):
    return np.concatenate([c[f"xi_pv_{split}"], c[f"xi_wt_{split}"]], axis=1)


def net_atoms(c, nd, split, eps):
    """dV (generation sign) and W_inf worst-case drop/surge terms, (N,nb,T)."""
    xr = xi_re(c, split)
    dV = np.einsum("bu,nut->nbt", nd["Ru"], xr)
    if eps > 0:
        cap = nd["cap_u"][None, :, None]; fc = nd["fc_u"][None]
        drop = np.minimum(eps * cap, np.maximum(fc + xr, 0.0))
        surge = np.minimum(eps * cap, np.maximum(cap - fc - xr, 0.0))
        rm = np.einsum("bu,nut->nbt", nd["Ru"], drop)
        rp = np.einsum("bu,nut->nbt", nd["Ru"], surge)
    else:
        rm = np.zeros_like(dV); rp = np.zeros_like(dV)
    return dV, rm, rp


def slopes(c, dd, beta):
    """(S_ch, S_dis) used for the reserve CC under each price model."""
    if dd == "blind":
        return 0.0, 0.0
    if dd == "robust":
        return c["S_ch"] * (1 + beta), c["S_dis"] * (1 - beta)
    return c["S_ch"], c["S_dis"]


def res_atoms(c, spec, pars, x_fixed=None):
    """Capacity coefficients so that  cap_ch = P (C0ch - C1ch x),  cap_dis = P (C0d + C1d x)."""
    a = c["ev_avail"][None]; xe = c["xi_ev_train"]; chi = c["chi"]
    eps = pars["eps"] if spec["ball"] else 0.0
    if spec["dd"] == "outer":                     # Prop. 1 outer ball (fixed price only)
        assert x_fixed is not None, "Proposed_P1 is defined for a fixed price"
        b = pars["beta"]; x = x_fixed[None]
        Sch, Sdis = c["S_ch"], c["S_dis"]
        av = np.maximum(a + xe, 0.0)
        amax = av.max(0, keepdims=True)
        Lch = 1 - Sch * (1 - b) * x; Ldis = chi + Sdis * (1 + b) * x
        cch = np.maximum(av * (1 - Sch * x) - Lch * eps - amax * b * Sch * x, 0.0)
        cdis = np.maximum(av * (chi + Sdis * x) - Ldis * eps - amax * b * Sdis * x, 0.0)
        z = np.zeros_like(cch)
        return cch, z, cdis, z
    A = np.maximum(a + xe - eps, 0.0)
    A[A < 1e-9] = 0.0                              # drop rounding noise
    Sch, Sdis = slopes(c, spec["dd"], pars["beta"])
    return A, A * Sch, A * chi, A * Sdis


def cvar(g, alpha):
    g = np.sort(np.asarray(g, float))[::-1]
    n = len(g); k = alpha * n; kf = int(np.floor(k + 1e-9))
    s = g[:kf].sum() + ((k - kf) * g[kf] if kf < n else 0.0)
    return s / k


# ---------------------------------------------------------------------------
# master problem
# ---------------------------------------------------------------------------
class Master:
    def __init__(self, c, method, pars, x_fixed=None):
        self.c, self.method, self.pars = c, method, pars
        self.spec = spec = SPEC[method]
        nb, T, SB = int(c["nbus"]), int(c["T"]), c["SBASE"]
        K = len(c["eva_buses"]); G = len(c["dg_buses"])
        self.nb, self.T, self.K, self.G = nb, T, K, G
        evab = list(map(int, c["eva_buses"])); pvb = list(map(int, c["pv_buses"]))
        wtb = list(map(int, c["wt_buses"])); dgb = list(map(int, c["dg_buses"]))
        Pm, Emax, avail = c["ev_Pmax"], c["ev_Emax"], c["ev_avail"]
        Eth_lo, Eth_hi, E_dep = c["Eth_lo"], c["Eth_hi"], c["E_dep"]
        chi, ramp, scv = c["chi"], c["ramp_frac"], c["scv"]
        eta = 0.95; dt = 1.0
        vmin2, vmax2, v0 = c["Vmin"] ** 2, c["Vmax"] ** 2, c["v0"]
        W = set(int(t) for t in c["W"])
        self.W = sorted(W)
        Sf_ch, Sf_dis = (0.0, 0.0) if spec["dd"] == "blind" else (c["S_ch"], c["S_dis"])
        S_inc = 0.0 if spec["dd"] == "blind" else c["S_dis"]
        xmax = pars["x_max"]

        m = gp.Model(method)
        m.Params.OutputFlag = 1 if pars["verbose"] else 0
        m.Params.MIPGap = pars["mipgap"]; m.Params.TimeLimit = pars["time_limit"]
        if pars.get("threads"):
            m.Params.Threads = pars["threads"]
        self.m = m

        # ---- price deviation x = pi - 1 (only in the DR window) ----
        self.price_var = x_fixed is None
        x = {}
        for k in range(K):
            for t in range(T):
                if t not in W:
                    x[k, t] = 0.0
                elif x_fixed is not None:
                    x[k, t] = float(x_fixed[k, t])
                else:
                    x[k, t] = m.addVar(lb=0.0, ub=xmax, name=f"x[{k},{t}]")
        self.x = x

        # ---- DG, PV, WT ----
        pdg = m.addVars(G, T, lb=0); qdg = m.addVars(G, T, lb=-GRB.INFINITY)
        for g in range(G):
            for t in range(T):
                m.addConstr(pdg[g, t] <= c["dg_Pmax"][g])
                m.addConstr(pdg[g, t] * pdg[g, t] + qdg[g, t] * qdg[g, t] <= c["dg_Pmax"][g] ** 2)
                if t > 0:
                    m.addConstr(pdg[g, t] - pdg[g, t - 1] <= c["dg_ramp"][g])
                    m.addConstr(pdg[g, t - 1] - pdg[g, t] <= c["dg_ramp"][g])
        ppv = m.addVars(len(pvb), T, lb=0); qpv = m.addVars(len(pvb), T, lb=-GRB.INFINITY)
        pwt = m.addVars(len(wtb), T, lb=0); qwt = m.addVars(len(wtb), T, lb=-GRB.INFINITY)
        for a_ in range(len(pvb)):
            for t in range(T):
                m.addConstr(ppv[a_, t] <= c["PV_fc"][a_, t])
                m.addConstr(ppv[a_, t] * ppv[a_, t] + qpv[a_, t] * qpv[a_, t] <= (1.1 * c["pv_cap"][a_]) ** 2)
        for a_ in range(len(wtb)):
            for t in range(T):
                m.addConstr(pwt[a_, t] <= c["WT_fc"][a_, t])
                m.addConstr(pwt[a_, t] * pwt[a_, t] + qwt[a_, t] * qwt[a_, t] <= (1.1 * c["wt_cap"][a_]) ** 2)

        # ---- EVA ----
        pch = m.addVars(K, T, lb=0); pdis = m.addVars(K, T, lb=0); qev = m.addVars(K, T, lb=-GRB.INFINITY)
        E = m.addVars(K, T, lb=0); u = m.addVars(K, T, vtype=GRB.BINARY)
        rup = m.addVars(K, T, lb=0); rdn = m.addVars(K, T, lb=0); rps = m.addVars(T, lb=0)
        sat = m.addVars(K, lb=0); seb = m.addVars(K, T, lb=0); slb = m.addVars(K, T, lb=0)
        wv = {}
        for k in range(K):
            for t in range(T):
                if isinstance(x[k, t], float):
                    wv[k, t] = x[k, t] * u[k, t]
                else:                                   # w = u x, exact (binary x bounded)
                    w_ = m.addVar(lb=0.0, ub=xmax)
                    m.addConstr(w_ <= xmax * u[k, t]); m.addConstr(w_ <= x[k, t])
                    m.addConstr(w_ >= x[k, t] - xmax * (1 - u[k, t]))
                    wv[k, t] = w_
                aP = avail[k, t] * Pm[k]
                # forecast range: charge share c = 1 - S x, V2G share d = chi + S x
                m.addConstr(pch[k, t] <= aP * (u[k, t] - Sf_ch * wv[k, t]) + 1e-6)
                m.addConstr(pdis[k, t] <= aP * (chi * (1 - u[k, t]) + Sf_dis * (x[k, t] - wv[k, t])) + 1e-6)
                pb = pch[k, t] - pdis[k, t]
                m.addConstr(pb + rup[k, t] <= aP * (1 - Sf_ch * x[k, t]) + 1e-6)
                m.addConstr(pb - rdn[k, t] >= -aP * (chi + Sf_dis * x[k, t]) - 1e-6)
                m.addConstr(pb * pb + qev[k, t] * qev[k, t] <= (scv * Pm[k]) ** 2)
                if t > 0:
                    m.addConstr(pch[k, t] - pch[k, t - 1] <= ramp * Pm[k])
                    m.addConstr(pch[k, t - 1] - pch[k, t] <= ramp * Pm[k])
                Eprev = E[k, t - 1] if t > 0 else float(Eth_lo[k, 0])
                m.addConstr(E[k, t] == Eprev + (eta * pch[k, t] - pdis[k, t] / eta) * dt)
                m.addConstr(E[k, t] <= float(Eth_hi[k, t]) + seb[k, t])
                m.addConstr(E[k, t] + slb[k, t] >= float(Eth_lo[k, t]))
                m.addConstr(E[k, t] <= float(Emax[k]))
            edk = int(c["edep_t"][k])
            m.addConstr(E[k, edk] + sat[k] >= E_dep[k])
        for t in range(T):
            m.addConstr(rps[t] <= gp.quicksum(rdn[k, t] for k in range(K)))

        # ---- SOCP branch flow at the forecast (Baran-Wu) ----
        children, *_ = radial_tree(c["branches"], nb)
        P = m.addVars(nb - 1, T, lb=-GRB.INFINITY); Q = m.addVars(nb - 1, T, lb=-GRB.INFINITY)
        v = m.addVars(range(1, nb + 1), T, lb=0.5 ** 2, ub=1.5 ** 2)
        ell = m.addVars(nb - 1, T, lb=0)
        svh = m.addVars(range(1, nb + 1), T, lb=0); svl = m.addVars(range(1, nb + 1), T, lb=0)
        sth = m.addVars(nb - 1, T, lb=0); ssub = m.addVars(T, lb=0)
        edges = c["branches"]; e_by_child = {int(edges[e, 1]): e for e in range(nb - 1)}
        r_e, x_e = edges[:, 2], edges[:, 3]
        for t in range(T):
            m.addConstr(v[1, t] == v0 ** 2)
            for b in range(2, nb + 1):
                pc = c["P_load"][b, t] \
                    - gp.quicksum(ppv[a_, t] for a_, bb in enumerate(pvb) if bb == b) \
                    - gp.quicksum(pwt[a_, t] for a_, bb in enumerate(wtb) if bb == b) \
                    - gp.quicksum(pdg[g, t] for g, bb in enumerate(dgb) if bb == b) \
                    + gp.quicksum(pch[k, t] - pdis[k, t] for k, bb in enumerate(evab) if bb == b)
                qc = c["Q_load"][b, t] \
                    - gp.quicksum(qpv[a_, t] for a_, bb in enumerate(pvb) if bb == b) \
                    - gp.quicksum(qwt[a_, t] for a_, bb in enumerate(wtb) if bb == b) \
                    - gp.quicksum(qdg[g, t] for g, bb in enumerate(dgb) if bb == b) \
                    - gp.quicksum(qev[k, t] for k, bb in enumerate(evab) if bb == b)
                e = e_by_child[b]; ch = [e_by_child[cc] for cc, _ in children[b]]
                m.addConstr(P[e, t] == pc / SB + gp.quicksum(P[cc, t] for cc in ch) + r_e[e] * ell[e, t])
                m.addConstr(Q[e, t] == qc / SB + gp.quicksum(Q[cc, t] for cc in ch) + x_e[e] * ell[e, t])
                par = int(edges[e, 0])
                m.addConstr(v[b, t] == v[par, t] - 2 * (r_e[e] * P[e, t] + x_e[e] * Q[e, t])
                            + (r_e[e] ** 2 + x_e[e] ** 2) * ell[e, t])
                m.addConstr(P[e, t] * P[e, t] + Q[e, t] * Q[e, t] <= ell[e, t] * v[par, t])
                m.addConstr(ell[e, t] <= c["Smax_pu"][e] ** 2 + sth[e, t])
            for b in range(1, nb + 1):
                m.addConstr(v[b, t] <= vmax2 + svh[b, t]); m.addConstr(v[b, t] >= vmin2 - svl[b, t])
            head = [e_by_child[cc] for cc, _ in children[1]]
            m.addConstr(gp.quicksum(P[cc, t] for cc in head) <= c["Smax_sub"] / SB + ssub[t])
            m.addConstr(gp.quicksum(P[cc, t] for cc in head) >= -c["Smax_sub"] / SB - ssub[t])
        self.head = head
        sec_pen = C_SEC * (svh.sum() + svl.sum() + sth.sum() + ssub.sum())

        # ---- chance-constraint skeletons ----
        N = c["xi_ev_train"].shape[0]; self.N = N
        cnet = m.addVar(lb=0); cres = m.addVar(lb=0)
        self.cnet, self.cres = cnet, cres
        self.g = self.h = None
        if spec["risk"] in ("cvar", "robust"):
            self.g = m.addVars(N, lb=-1.0); self.h = m.addVars(N, lb=-10.0)
            if spec["risk"] == "cvar":
                al = pars["alpha"]
                self.zg = m.addVar(lb=-GRB.INFINITY); self.zh = m.addVar(lb=-GRB.INFINITY)
                sg = m.addVars(N, lb=0); sh = m.addVars(N, lb=0); self.sg, self.sh = sg, sh
                for i in range(N):
                    m.addConstr(sg[i] >= self.g[i] - self.zg)
                    m.addConstr(sh[i] >= self.h[i] - self.zh)
                m.addConstr(self.zg + sg.sum() / (al * N) <= cnet)
                m.addConstr(self.zh + sh.sum() / (al * N) <= cres)
            else:
                for i in range(N):
                    m.addConstr(self.g[i] <= cnet); m.addConstr(self.h[i] <= cres)
        self.pieces_net = set(); self.pieces_res = set(); self.zdn = {}; self.zup = {}

        # ---- objective ----
        SBh = SB
        energy = gp.quicksum(c["Cgrid"][t] * gp.quicksum(P[cc, t] for cc in head) * SBh * dt for t in range(T))
        dgc = gp.quicksum((c["dg_a"][g] * pdg[g, t] * pdg[g, t] + c["dg_b"][g] * pdg[g, t]) * dt
                          for g in range(G) for t in range(T))
        deg = gp.quicksum(c["Cdeg"] * pdis[k, t] * dt for k in range(K) for t in range(T))
        anc = gp.quicksum(c["rho_up"][t] * rup[k, t] + c["rho_dn"][t] * rdn[k, t]
                          for k in range(K) for t in range(T)) \
            + gp.quicksum(c["rho_ps"][t] * rps[t] for t in range(T))
        cinc = gp.QuadExpr()
        for k in range(K):
            for t in self.W:
                aP = avail[k, t] * Pm[k]
                cinc += pars["rho_inc"] * aP * (chi * x[k, t] + S_inc * x[k, t] * x[k, t]) * dt
        satpen = c["Csat"] * (sat.sum() + seb.sum() + slb.sum())
        ccpen = C_NET * cnet + C_RES * cres
        m.setObjective(energy + dgc + deg - anc + cinc + satpen + sec_pen + ccpen, GRB.MINIMIZE)
        self.cinc_expr = cinc
        self.V = dict(pch=pch, pdis=pdis, E=E, u=u, rup=rup, rdn=rdn, rps=rps, pdg=pdg, ppv=ppv,
                      pwt=pwt, v=v, P=P, svh=svh, svl=svl, sth=sth, ssub=ssub, sat=sat, seb=seb, slb=slb)
        self.vmin2, self.vmax2 = vmin2, vmax2

        # ---- moment-based DRCC: individual Cantelli constraints, all pieces up front ----
        if spec["risk"] == "moment":
            self._add_moment()

    # -- individual mean/std (Cantelli) constraints for Moment-DRO --
    def _add_moment(self):
        c, m, V, K, T, nb = self.c, self.m, self.V, self.K, self.T, self.nb
        nd = net_data(c); kap = np.sqrt((1 - self.pars["alpha"]) / self.pars["alpha"])
        self.mslack_net, self.mslack_res = [], []
        dV, _, _ = net_atoms(c, nd, "train", 0.0)
        mu, sd = dV.mean(0), dV.std(0)
        xe = c["xi_ev_train"]; a = c["ev_avail"]; Pm = c["ev_Pmax"]; chi = c["chi"]
        Am = np.maximum(a + xe.mean(0) - kap * xe.std(0), 0.0)
        zd = m.addVars(K, T, lb=-GRB.INFINITY); zu = m.addVars(K, T, lb=-GRB.INFINITY)
        for k in range(K):
            for t in range(T):
                pb = V["pch"][k, t] - V["pdis"][k, t]
                m.addConstr(zd[k, t] >= -V["rdn"][k, t]); m.addConstr(zd[k, t] >= -Pm[k] * Am[k, t] * chi - pb)
                m.addConstr(zu[k, t] <= V["rup"][k, t]); m.addConstr(zu[k, t] <= Pm[k] * Am[k, t] - pb)
        for b in range(2, nb + 1):
            for t in range(T):
                rdn_term = gp.quicksum(nd["Rk"][b - 1, k] * zd[k, t] for k in range(K))
                rup_term = gp.quicksum(nd["Rk"][b - 1, k] * zu[k, t] for k in range(K))
                s1 = m.addVar(lb=0); s2 = m.addVar(lb=0); self.mslack_net += [s1, s2]
                m.addConstr(self.vmin2 - V["v"][b, t] - mu[b - 1, t] + kap * sd[b - 1, t] + rdn_term <= s1)
                m.addConstr(V["v"][b, t] + mu[b - 1, t] + kap * sd[b - 1, t] - rup_term - self.vmax2 <= s2)
        for k in range(K):
            for t in range(T):
                pb = V["pch"][k, t] - V["pdis"][k, t]
                s1 = m.addVar(lb=0); s2 = m.addVar(lb=0); self.mslack_res += [s1, s2]
                m.addConstr(pb + V["rup"][k, t] - Pm[k] * Am[k, t] - TAU * Pm[k] <= s1)
                m.addConstr(-Pm[k] * Am[k, t] * chi - pb + V["rdn"][k, t] - TAU * Pm[k] <= s2)
        m.addConstr(self.cnet == gp.quicksum(self.mslack_net))
        m.addConstr(self.cres == gp.quicksum(self.mslack_res))

    # -- deliverable recourse of day i at hour t under the method's own range model --
    def _recourse(self, i, t, RA):
        if (i, t) in self.zdn:
            return self.zdn[i, t], self.zup[i, t]
        m, V, Pm = self.m, self.V, self.c["ev_Pmax"]; C0ch, C1ch, C0d, C1d = RA
        zd, zu = [], []
        for k in range(self.K):
            x = self.x[k, t]; pb = V["pch"][k, t] - V["pdis"][k, t]
            lo = -Pm[k] * (C0d[i, k, t] + C1d[i, k, t] * x)
            hi = Pm[k] * (C0ch[i, k, t] - C1ch[i, k, t] * x)
            a_ = m.addVar(lb=-GRB.INFINITY); b_ = m.addVar(lb=-GRB.INFINITY)
            m.addConstr(a_ >= -V["rdn"][k, t]); m.addConstr(a_ >= lo - pb)     # down: max(-rdn, lo-pb)
            m.addConstr(b_ <= V["rup"][k, t]); m.addConstr(b_ <= hi - pb)      # up:   min(rup, hi-pb)
            zd.append(a_); zu.append(b_)
        self.zdn[i, t], self.zup[i, t] = zd, zu
        return zd, zu

    # -- lazy pieces --
    def add_net(self, i, b, t, kind, dV, rm, rp, RA):
        if (i, b, t, kind) in self.pieces_net:
            return
        self.pieces_net.add((i, b, t, kind))
        nd, V, K = self.nd, self.V, self.K
        zd, zu = self._recourse(i, t, RA)
        if kind == 0:   # under-voltage with the deliverable down-recourse
            expr = self.vmin2 - V["v"][b, t] - dV[i, b - 1, t] + rm[i, b - 1, t] \
                + gp.quicksum(nd["Rk"][b - 1, k] * zd[k] for k in range(K))
        else:           # over-voltage with the deliverable up-recourse
            expr = V["v"][b, t] + dV[i, b - 1, t] + rp[i, b - 1, t] - self.vmax2 \
                - gp.quicksum(nd["Rk"][b - 1, k] * zu[k] for k in range(K))
        self.m.addConstr(expr <= self.g[i])

    def add_res(self, i, k, t, kind, RA):
        if (i, k, t, kind) in self.pieces_res:
            return
        self.pieces_res.add((i, k, t, kind))
        V = self.V; Pm = self.c["ev_Pmax"][k]; C0ch, C1ch, C0d, C1d = RA
        x = self.x[k, t]; pb = V["pch"][k, t] - V["pdis"][k, t]
        cl = lambda v: v if abs(v) > 1e-9 else 0.0
        if kind == 0:
            expr = pb + V["rup"][k, t] - Pm * (cl(C0ch[i, k, t]) - cl(C1ch[i, k, t]) * x) - TAU * Pm
        else:
            expr = -Pm * (cl(C0d[i, k, t]) + cl(C1d[i, k, t]) * x) - pb + V["rdn"][k, t] - TAU * Pm
        self.m.addConstr(expr <= self.h[i])

    def snapshot(self):
        self._vars = self.m.getVars(); self._xs = self.m.getAttr("X", self._vars)

    def solve(self, start_over=None):
        """Re-solve; the previous solution, repaired for the new pieces, is a complete MIP start."""
        if getattr(self, "_vars", None) is not None:
            self.m.update()
            self.m.setAttr("Start", self._vars, self._xs)
            for var, val in (start_over or []):
                var.Start = val
        self.m.optimize()
        if self.m.SolCount == 0 and getattr(self, "_vars", None) is not None:
            # fallback: fix the previous charge-mode pattern and solve the convex problem
            u = self.V["u"]; old = {k: v.Start for k, v in u.items()}
            for k, v in u.items():
                v.LB = v.UB = round(old[k])
            self.m.optimize()
            for k, v in u.items():
                v.LB, v.UB = 0.0, 1.0
            self.fixed_fallback = True
        return self.m.SolCount > 0

    def solution(self):
        m, V, K, T, G, nb = self.m, self.V, self.K, self.T, self.G, self.nb
        arr = lambda d, n: np.array([[d[i, t].X for t in range(T)] for i in range(n)])
        x = np.array([[(self.x[k, t].X if not isinstance(self.x[k, t], float) else self.x[k, t])
                       for t in range(T)] for k in range(K)])
        vsq = np.zeros((nb + 1, T)); vsq[0] = self.c["v0"] ** 2
        for b in range(1, nb + 1):
            for t in range(T):
                vsq[b, t] = V["v"][b, t].X
        Pflow = arr(V["P"], nb - 1)
        sumX = lambda d: float(sum(z.X for z in d.values()))
        sec = sumX(V["svh"]) + sumX(V["svl"]) + sumX(V["sth"]) + sumX(V["ssub"])
        cinc = self.cinc_expr.getValue()
        obj = m.ObjVal
        econ = obj - C_SEC * sec - C_NET * self.cnet.X - C_RES * self.cres.X
        return dict(obj=obj, bound=getattr(m, "ObjBound", obj), econ=econ, cinc=cinc, sec_slack=sec,
                    cnet=self.cnet.X, cres=self.cres.X, x=x, vsq=vsq, Pflow=Pflow,
                    pch=arr(V["pch"], K), pdis=arr(V["pdis"], K), E=arr(V["E"], K),
                    rup=arr(V["rup"], K), rdn=arr(V["rdn"], K),
                    rps=np.array([V["rps"][t].X for t in range(T)]),
                    pdg=arr(V["pdg"], G), ppv=arr(V["ppv"], len(self.c["pv_buses"])),
                    pwt=arr(V["pwt"], len(self.c["wt_buses"])),
                    sat=np.array([V["sat"][k].X for k in range(K)]),
                    stats=dict(nvars=m.NumVars, nbin=m.NumBinVars, ncons=m.NumConstrs,
                               nqcons=m.NumQConstrs, runtime=m.Runtime))


# ---------------------------------------------------------------------------
# exact loss evaluation on the training atoms (for UB and piece generation)
# ---------------------------------------------------------------------------
def model_range(c, x, RA):
    """Realised range of each training day under the method's own model, (N,K,T)."""
    Pm = c["ev_Pmax"][None, :, None]; C0ch, C1ch, C0d, C1d = RA
    return -Pm * (C0d + C1d * x[None]), Pm * (C0ch - C1ch * x[None])


def net_pieces(c, nd, sol, dV, rm, rp, RA):
    """Signed voltage pieces with the deliverable recourse (same as the master)."""
    vmin2, vmax2 = c["Vmin"] ** 2, c["Vmax"] ** 2
    v = sol["vsq"][1:]
    pb = (sol["pch"] - sol["pdis"])[None]
    lo, hi = model_range(c, sol["x"], RA)
    zd = np.maximum(-sol["rdn"][None], lo - pb)                      # deliverable down
    zu = np.minimum(sol["rup"][None], hi - pb)                       # deliverable up
    Rzd = np.einsum("bk,nkt->nbt", nd["Rk"], zd); Rzu = np.einsum("bk,nkt->nbt", nd["Rk"], zu)
    base_u = vmin2 - v[None] - dV + rm; base_o = v[None] + dV + rp - vmax2
    U = base_u + Rzd; O = base_o - Rzu                                # relaxation pieces
    Olow = base_o - Rzd; Uhigh = base_u + Rzu                         # same deployment for both
    for A in (U, O, Olow, Uhigh):
        A[:, 0, :] = -np.inf                                         # substation bus fixed
    Gr = np.maximum(U.max(1), O.max(1))
    Gub = np.minimum(np.maximum(U.max(1), Olow.max(1)), np.maximum(Uhigh.max(1), O.max(1)))
    return U, O, Gr.max(1), Gub.max(1)


def res_pieces(c, sol, x, RA):
    Pm = c["ev_Pmax"][None, :, None]; C0ch, C1ch, C0d, C1d = RA
    pb = (sol["pch"] - sol["pdis"])[None]
    CH = pb + sol["rup"][None] - Pm * (C0ch - C1ch * x[None]) - TAU * Pm
    DI = -Pm * (C0d + C1d * x[None]) - pb + sol["rdn"][None] - TAU * Pm
    return CH, DI, np.maximum(CH.max((1, 2)), DI.max((1, 2)))


def risk_value(vals, risk, alpha):
    if risk == "cvar":
        return cvar(vals, alpha)
    return float(np.max(vals))


# ---------------------------------------------------------------------------
# lazy constraint generation (valid LB / UB, finite termination)
# ---------------------------------------------------------------------------
def solve(c, method, pars, x_fixed=None, log_fn=print):
    spec = SPEC[method]
    t0 = time.time()
    M = Master(c, method, pars, x_fixed)
    nd = net_data(c); M.nd = nd
    eps = pars["eps"] if spec["ball"] else 0.0
    dV, rm, rp = net_atoms(c, nd, "train", eps)
    RA = res_atoms(c, spec, pars, x_fixed)
    log = dict(it=[], LB=[], UB=[], master=[], npieces=[], t=[], fallback=[])
    best, UB, LB = None, np.inf, -np.inf
    start_over = None
    for it in range(1, pars["max_iter"] + 1):
        M.fixed_fallback = False
        if not M.solve(start_over):
            log_fn(f"  [{method}] master returned no solution (status {M.m.Status})")
            break
        sol = M.solution()
        x = sol["x"]
        if spec["risk"] in ("cvar", "robust"):
            U, O, g_rel, g_ub = net_pieces(c, nd, sol, dV, rm, rp, RA)
            CH, DI, h = res_pieces(c, sol, x, RA)
            cn = max(0.0, risk_value(g_ub, spec["risk"], pars["alpha"]))
            cr = max(0.0, risk_value(h, spec["risk"], pars["alpha"]))
            ub = sol["econ"] + C_SEC * sol["sec_slack"] + C_NET * cn + C_RES * cr
        else:
            ub = sol["obj"]
        if not M.fixed_fallback:                   # bound of a relaxation: valid lower bound
            LB = max(LB, sol["bound"])
        if ub < UB:
            UB, best = ub, dict(sol)
            if spec["risk"] in ("cvar", "robust"):
                best.update(cnet_true=cn, cres_true=cr, g=g_ub, h=h)
        log["it"].append(it); log["LB"].append(LB); log["UB"].append(UB); log["master"].append(sol["obj"])
        log["npieces"].append(len(M.pieces_net) + len(M.pieces_res)); log["t"].append(time.time() - t0)
        log["fallback"].append(bool(M.fixed_fallback))
        log_fn(f"  [{method}] it {it}: LB {LB:10.2f}  master {sol['obj']:10.2f}  UB {UB:10.2f}  "
               f"pieces {log['npieces'][-1]:6d}  t {time.time()-t0:6.1f}s{'  (fixed-mode fallback)' if M.fixed_fallback else ''}")
        if spec["risk"] not in ("cvar", "robust"):
            break
        slack_ok = spec["risk"] not in ("cvar", "robust") or (cn <= 1e-7 and cr <= 1e-6)
        if UB - LB <= pars["tol_rel"] * max(abs(UB), 1.0) and (slack_ok or it >= 3 and
                                                             best.get("cnet_true", 0) + best.get("cres_true", 0) > 1e-3):
            break
        # ---- add violated pieces where they can change the risk value ----
        gm = np.array([M.g[i].X for i in range(M.N)]); hm = np.array([M.h[i].X for i in range(M.N)])
        if spec["risk"] == "cvar":
            thr_g, thr_h = M.zg.X, M.zh.X
        else:
            thr_g, thr_h = -np.inf, -np.inf
        M.snapshot()
        old_z = set(M.zdn)
        g_st, h_st = gm.copy(), hm.copy()
        added = 0
        # worst voltage piece of every hour (spreads the cuts over hours, not adjacent buses)
        UO = np.stack([U, O], 1)                                   # (N,2,nb,T)
        flat = UO.transpose(0, 3, 1, 2).reshape(M.N, UO.shape[3], -1)   # (N,T,2*nb)
        jbest = flat.argmax(2); vbest = flat.max(2)                # (N,T)
        nb_ = U.shape[1]
        for i in range(M.N):
            if g_rel[i] > max(gm[i], thr_g) + 1e-7:
                for t in np.argsort(vbest[i])[::-1][:pars["n_add"]]:
                    if vbest[i, t] <= gm[i] + 1e-7:
                        break
                    kind, b0 = divmod(int(jbest[i, t]), nb_)
                    M.add_net(i, b0 + 1, int(t), kind, dV, rm, rp, RA); added += 1
                    g_st[i] = max(g_st[i], vbest[i, t])
            if h[i] > max(hm[i], thr_h) + 1e-7:
                K_, T2 = CH.shape[1], CH.shape[2]
                allp = np.concatenate([CH[i].ravel(), DI[i].ravel()])
                for j in np.argsort(allp)[::-1][:pars["n_add"]]:
                    if allp[j] <= hm[i] + 1e-7:
                        break
                    kind, rest = divmod(int(j), K_ * T2); k, t = divmod(rest, T2)
                    M.add_res(i, k, t, kind, RA); added += 1
                    h_st[i] = max(h_st[i], allp[j])
        if added == 0:
            gap_m = getattr(M.m, "MIPGap", 0.0) if M.m.SolCount else 1.0
            if gap_m > 2 * pars["mipgap"] and M.m.Params.TimeLimit < 8 * pars["time_limit"]:
                M.m.Params.TimeLimit = 2 * M.m.Params.TimeLimit        # master not solved: give it more time
                log_fn(f"  [{method}] master MIP gap {100*gap_m:.2f}% -> re-solving with {M.m.Params.TimeLimit:.0f}s")
                M.snapshot(); start_over = []
                continue
            log_fn(f"  [{method}] no violated piece left; gap from master MIP tolerance / recourse bound")
            break
        # ---- repaired complete start: previous solution + feasible values for the new pieces ----
        start_over = []
        lo, hi = model_range(c, x, RA); pb = (sol["pch"] - sol["pdis"])[None]
        zd = np.maximum(-sol["rdn"][None], lo - pb); zu = np.minimum(sol["rup"][None], hi - pb)
        for (i, t) in set(M.zdn) - old_z:
            for k in range(M.K):
                start_over += [(M.zdn[i, t][k], float(zd[i, k, t])), (M.zup[i, t][k], float(zu[i, k, t]))]
        for vals, var, svar, zvar, cvar_ in ((g_st, M.g, getattr(M, "sg", None), getattr(M, "zg", None), M.cnet),
                                             (h_st, M.h, getattr(M, "sh", None), getattr(M, "zh", None), M.cres)):
            for i in range(M.N):
                start_over.append((var[i], float(vals[i])))
            if spec["risk"] == "cvar":
                al = pars["alpha"]; kq = int(np.ceil(al * M.N)) - 1
                z0 = float(np.sort(vals)[::-1][kq]); sv = np.maximum(vals - z0, 0.0)
                for i in range(M.N):
                    start_over.append((svar[i], float(sv[i])))
                start_over += [(zvar, z0), (cvar_, max(0.0, z0 + sv.sum() / (al * M.N)) + 1e-9)]
            else:
                start_over.append((cvar_, max(0.0, float(vals.max())) + 1e-9))
    log["time_s"] = time.time() - t0
    if best is not None:
        best["stats"] = M.solution()["stats"] if M.m.SolCount else {}
        best["npieces"] = len(M.pieces_net) + len(M.pieces_res)
        best["rho_inc"] = pars["rho_inc"]; best["method"] = method; best["eps"] = eps
    return best, log


# ---------------------------------------------------------------------------
# out-of-sample evaluation against the true response
# ---------------------------------------------------------------------------
def evaluate(c, sol, split="test", nd=None):
    nd = nd or net_data(c)
    x = sol["x"]; Pm = c["ev_Pmax"][None, :, None]; a = c["ev_avail"][None]
    xe = c[f"xi_ev_{split}"]; mm = c[f"m_{split}"]
    ct, dt_ = true_factors(c, x, mm)
    A = np.maximum(a + xe, 0.0)
    hi = A * Pm * ct; lo = -A * Pm * dt_
    pb = (sol["pch"] - sol["pdis"])[None]; rup = sol["rup"][None]; rdn = sol["rdn"][None]
    sf = np.maximum(np.maximum(pb + rup - hi, lo - (pb - rdn)) - TAU * Pm, 0.0)
    res_fail = (sf > 1e-9).any((1, 2))
    undel = sf.sum((1, 2))                                    # MWh (hourly steps)
    # real-time EV power inside the deliverable part of the band
    lowI = np.maximum(pb - rdn, lo); highI = np.minimum(pb + rup, hi)
    empty = lowI > highI
    proj = np.clip(np.broadcast_to(pb, hi.shape), lo, hi)
    lowI = np.where(empty, proj, lowI); highI = np.where(empty, proj, highI)
    vmin2, vmax2 = c["Vmin"] ** 2, c["Vmax"] ** 2
    v = sol["vsq"][1:][None]
    dVre = np.einsum("bu,nut->nbt", nd["Ru"], xi_re(c, split))

    def volt(y):
        dVev = -np.einsum("bk,nkt->nbt", nd["Rk"], y - pb)
        vr = v + dVre + dVev
        un = np.maximum(vmin2 - vr, 0.0); ov = np.maximum(vr - vmax2, 0.0)
        un[:, 0, :] = 0.0; ov[:, 0, :] = 0.0
        return un, ov
    un_l, ov_l = volt(lowI); un_h, ov_h = volt(highI)
    use_low = ov_l.max(1) <= 1e-9                            # (N,T)
    use_high = (~use_low) & (un_h.max(1) <= 1e-9)
    conflict = ~(use_low | use_high)
    vio_low = (un_l + ov_l).sum(1); vio_high = (un_h + ov_h).sum(1)
    choose_low = use_low | (conflict & (vio_low <= vio_high))
    vmag = np.where(choose_low, vio_low, vio_high)             # (N,T) summed over buses
    y = np.where(choose_low[:, None, :], lowI, highI)
    # thermal check with the chosen deployment
    cons = np.zeros((xe.shape[0], int(c["nbus"]), int(c["T"])))
    ubus = np.concatenate([c["pv_buses"], c["wt_buses"]]).astype(int)
    xr = xi_re(c, split)
    for u_, b in enumerate(ubus):
        cons[:, b - 1, :] -= xr[:, u_, :]
    for k, b in enumerate(np.asarray(c["eva_buses"], int)):
        cons[:, b - 1, :] += (y - pb)[:, k, :]
    flow = sol["Pflow"][None] + np.einsum("eb,nbt->net", nd["D"], cons) / c["SBASE"]
    thr = np.maximum(np.abs(flow) - c["Smax_pu"][None, :, None], 0.0)
    net_fail = (vmag > 1e-9).any(1) | (thr > 1e-9).any((1, 2))
    joint_fail = net_fail | res_fail
    # settled day-ahead cost with the true incentive payment
    W = c["W"]; avail = c["ev_avail"]; Pm1 = c["ev_Pmax"]
    pay = np.zeros(xe.shape[0])
    for k in range(len(Pm1)):
        for t in W:
            pay += sol["rho_inc"] * avail[k, t] * Pm1[k] * x[k, t] * dt_[:, k, t]
    settled = sol["econ"] - sol["cinc"] + pay.mean()
    return dict(n=int(xe.shape[0]), net_fail=net_fail, res_fail=res_fail, joint_fail=joint_fail,
                vmag=vmag.sum(1), undel=undel, worst_short=sf.max((1, 2)), thermal_any=bool((thr > 1e-9).any()),
                conflicts=int(conflict.sum()), settled=float(settled),
                total=float(settled + LAMBDA_RT * undel.mean()))


def summarize(ev):
    n = ev["n"]
    return dict(n=n, p_net=float(ev["net_fail"].mean()), p_res=float(ev["res_fail"].mean()),
                p_joint=float(ev["joint_fail"].mean()), undel_kWh=float(1e3 * ev["undel"].mean()),
                worst_kW=float(1e3 * ev["worst_short"].mean()), vmag=float(ev["vmag"].mean()),
                settled=ev["settled"], total=ev["total"], conflicts=ev["conflicts"],
                thermal_any=ev["thermal_any"])
