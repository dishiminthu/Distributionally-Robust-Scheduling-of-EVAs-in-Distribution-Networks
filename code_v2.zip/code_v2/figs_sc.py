"""figs_sc.py -- figures for the single-column Energy manuscript (../Energy_SC/figures).

Times New Roman for all text and math (TrueType fonts embedded).  Every legend
sits outside the axes, so no legend covers a line or a data point.
"""
import json, sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

HERE = Path(__file__).resolve().parent
FIG = HERE.parent / "Energy_SC" / "figures"; RES = HERE.parent / "results_v2"
BLUE, ORANGE, GREEN, GREY, DARK = "#2a78d6", "#eb6834", "#1baf7a", "#8c8c8c", "#333333"
W = 6.4                                                   # inches, single-column text width ~6.48 in
plt.rcParams.update({
    "font.family": "serif", "font.serif": ["Times New Roman"],
    "mathtext.fontset": "custom", "mathtext.rm": "Times New Roman", "mathtext.it": "Times New Roman:italic",
    "mathtext.bf": "Times New Roman:bold", "mathtext.sf": "Times New Roman",
    "pdf.fonttype": 42, "ps.fonttype": 42,
    "font.size": 9, "axes.labelsize": 9, "axes.titlesize": 9, "legend.fontsize": 8.5,
    "xtick.labelsize": 8.5, "ytick.labelsize": 8.5, "axes.spines.top": False, "axes.spines.right": False,
    "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": 0.5, "lines.linewidth": 1.4,
    "legend.frameon": False, "savefig.bbox": "tight", "savefig.pad_inches": 0.03, "axes.unicode_minus": False})

LABEL = {"DET": "M1 DET", "SAA_CVaR": "M2 SAA-CVaR", "Moment_DRO": "M3 Moment-DRO", "Exo_Winf": r"M4 Exo-W$_\infty$",
         "Robust_DDU": "M5 Robust-DDU", "DD_CVaR": "M6 DD-CVaR", "Proposed": "M7 Proposed"}
STYLE = {"SAA_CVaR": (GREY, "v"), "Exo_Winf": (GREEN, "D"), "Robust_DDU": (ORANGE, "s"),
         "DD_CVaR": (DARK, "^"), "Proposed": (BLUE, "o")}
TARGET = Line2D([], [], color=GREY, ls="-.", lw=0.9, label="target 10%")


def save(fig, name):
    fig.savefig(FIG / name); plt.close(fig); print("saved", name)


def _m(sname, exp, tag, meth):
    sys.path.insert(0, str(HERE)); import select_v2 as S
    r = S.load(sname, exp, tag, meth)
    return None if r is None else (S.metrics(r), r)


def fig_profiles():
    sys.path.insert(0, str(HERE)); import run_v2 as R
    c = R.case_for("33"); h = np.arange(1, 25)
    fig, axs = plt.subplots(1, 3, figsize=(W, 2.35))
    for ax in axs:
        ax.axvspan(8.5, 15.5, color="#f3ead2", lw=0, zorder=0)
        ax.set_xlim(0.5, 24.5); ax.set_xticks([1, 6, 12, 18, 24]); ax.set_xlabel("hour")
    axs[0].plot(h, c["Cgrid"], "-o", ms=3, color=BLUE, label="energy price")
    axs[0].set_ylabel("\\$/MWh")
    axs[1].plot(h, c["rho_up"], "-o", ms=3, color=BLUE, label=r"up reserve $\rho^{\mathrm{up}}$")
    axs[1].plot(h, c["rho_dn"], "--s", ms=3, color=ORANGE, label=r"down reserve $\rho^{\mathrm{dn}}$")
    axs[1].plot(h, c["rho_ps"], ":^", ms=3, color=GREEN, label=r"peak shaving $\rho^{\mathrm{ps}}$")
    axs[1].set_ylabel("\\$/MW")
    L = c["P_load"].sum(0); PV = c["PV_fc"].sum(0); WT = c["WT_fc"].sum(0)
    axs[2].plot(h, L / L.max(), "-o", ms=3, color=BLUE, label="load / peak")
    axs[2].plot(h, PV / c["pv_cap"].sum(), "--s", ms=3, color=ORANGE, label="PV / capacity")
    axs[2].plot(h, WT / c["wt_cap"].sum(), ":^", ms=3, color=GREEN, label="WT / capacity")
    axs[2].set_ylabel("normalised value")
    for ax, t in zip(axs, ["(a) energy price", "(b) capacity prices", "(c) load and renewables"]):
        ax.set_title(t, loc="left")
    hs, ls_ = [], []
    for ax in axs:
        h_, l_ = ax.get_legend_handles_labels(); hs += h_; ls_ += l_
    hs.append(Patch(color="#f3ead2", label="priced hours")); ls_.append("priced hours")
    fig.tight_layout(w_pad=1.4, rect=[0, 0.17, 1, 1])
    fig.legend(hs, ls_, loc="lower center", ncol=4, bbox_to_anchor=(0.5, 0.0), columnspacing=1.2)
    save(fig, "fig_profiles.pdf")


def fig_response():
    b = json.load(open(RES / "behaviour_summary.json"))
    x = np.array(b["bins"]); v2g = 100 * np.array(b["plugged_v2g_share"]); g2v = 100 * np.array(b["plugged_g2v_share"])
    fig, ax = plt.subplots(1, 2, figsize=(W, 2.9))
    a = ax[0]
    a.plot(x, g2v, "-o", color=BLUE, ms=3.5, label="G2V recommended")
    a.plot(x, v2g, "--s", color=ORANGE, ms=3.5, label="V2G recommended")
    a.axvline(1.0, color=GREY, lw=0.8, ls=":")
    a.set_xlabel(r"price ratio $\pi$"); a.set_ylabel("share of records (%)")
    a.set_ylim(-3, 103); a.set_title("(a) dataset", loc="left")
    a.legend(loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2)
    a = ax[1]
    pi = np.linspace(1.0, 1.5, 101); xx = pi - 1
    Sc, Sd, chi, beta, dc, dd = 0.30, 0.40, 0.5, 0.4, 0.25, 0.25
    for (nom, lo, hi, tl, th, col, mk) in [
        (1 - Sc * xx, 1 - Sc * (1 + beta) * xx, 1 - Sc * (1 - beta) * xx,
         1 - 1.4 * dc * np.tanh(Sc * xx / dc), 1 - 0.6 * dc * np.tanh(Sc * xx / dc), BLUE, "o"),
        (chi + Sd * xx, chi + Sd * (1 - beta) * xx, chi + Sd * (1 + beta) * xx,
         chi + 0.6 * dd * np.tanh(Sd * xx / dd), chi + 1.4 * dd * np.tanh(Sd * xx / dd), ORANGE, "s")]:
        a.fill_between(pi, lo, hi, color=col, alpha=0.13, lw=0)
        a.plot(pi, nom, "-", color=col); a.plot(pi[::25], nom[::25], mk, color=col, ms=3.5)
        a.plot(pi, tl, ":", color=col, lw=1.0); a.plot(pi, th, ":", color=col, lw=1.0)
    a.set_xlabel(r"price ratio $\pi$"); a.set_ylabel("share of connected EVs")
    a.set_title("(b) model and true response", loc="left")
    hnd = [Line2D([], [], color=BLUE, marker="o", ms=3.5, label=r"charging share $c(\pi)$"),
           Line2D([], [], color=ORANGE, marker="s", ms=3.5, label=r"V2G share $d(\pi)$"),
           Patch(color=GREY, alpha=0.3, label=r"model band $\pm40\%$"),
           Line2D([], [], color=GREY, ls=":", label="true response range")]
    a.legend(handles=hnd, loc="upper center", bbox_to_anchor=(0.5, -0.27), ncol=2)
    fig.tight_layout(w_pad=2.0); save(fig, "fig_response.pdf")


def fig_tradeoff():
    sys.path.insert(0, str(HERE)); import select_v2 as S
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.7))
    for ax, sname in zip(axs, ["33", "123"]):
        rows, _ = S.table(sname, "fixed")
        ref = rows["Proposed"]["total"]
        for m in ["SAA_CVaR", "Exo_Winf", "Robust_DDU", "DD_CVaR", "Proposed"]:
            r = rows[m]; col, mk = STYLE[m]
            xv = 100 * r["joint_fail"]; xl, xh = 100 * np.array(r["joint_fail_ci"])
            yv = 100 * (r["total"] / ref - 1); yl, yh = 100 * (np.array(r["total_ci"]) / ref - 1)
            ax.errorbar(xv, yv, xerr=[[xv - xl], [xh - xv]], yerr=[[yv - yl], [yh - yv]], fmt=mk, color=col,
                        ms=5, mec="white", mew=0.6, elinewidth=0.9, capsize=2, label=LABEL[m])
        ax.axvline(10, color=GREY, ls="-.", lw=0.9); ax.axhline(0, color=GREY, lw=0.6)
        ax.set_xlabel("system failure probability (%)"); ax.set_ylabel("total cost relative to M7 (%)")
        ax.set_title(f"({'a' if sname == '33' else 'b'}) IEEE {sname}-bus feeder", loc="left"); ax.set_xlim(0, 36)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h + [TARGET], l + ["target 10%"], loc="upper center", ncol=6, bbox_to_anchor=(0.5, 1.08),
               columnspacing=1.0, handletextpad=0.4)
    fig.tight_layout(w_pad=2.0); save(fig, "fig_tradeoff.pdf")


def fig_oprange():
    sys.path.insert(0, str(HERE)); import select_v2 as S, run_v2 as R
    tag, _ = S.select("33", "fixed", "Proposed")
    sol = S.load("33", "fixed", tag, "Proposed")["sol"]
    c = R.case_for("33"); a = c["ev_avail"]; Pm = c["ev_Pmax"]; x = sol["x"]
    hi = a * Pm[:, None] * (1 - c["S_ch"] * x); lo = -a * Pm[:, None] * (c["chi"] + c["S_dis"] * x)
    pb = sol["pch"] - sol["pdis"]; t = np.arange(1, 25)
    names = ["(a) EVA 1, residential, bus 18", "(b) EVA 2, residential, bus 22",
             "(c) EVA 3, commercial, bus 25", "(d) EVA 4, workplace, bus 33"]
    fig, axs = plt.subplots(2, 2, figsize=(W, 4.1), sharex=True)
    for k, ax in enumerate(axs.ravel()):
        ax.axvspan(8.5, 15.5, color="#f3ead2", lw=0, zorder=0)
        ax.fill_between(t, lo[k], hi[k], step="mid", color=GREY, alpha=0.22, lw=0)
        ax.fill_between(t, pb[k] - sol["rdn"][k], pb[k] + sol["rup"][k], step="mid", color=GREEN, alpha=0.45, lw=0)
        ax.step(t, pb[k], where="mid", color=BLUE, lw=1.4)
        ax.axhline(0, color=GREY, lw=0.6); ax.set_title(names[k], loc="left"); ax.set_xlim(0.5, 24.5)
        if k % 2 == 0:
            ax.set_ylabel("power (MW)")
        if k >= 2:
            ax.set_xlabel("hour")
    hnd = [Patch(color=GREY, alpha=0.4, label="forecast operating range"), Patch(color=GREEN, alpha=0.6, label="reserve band"),
           Line2D([], [], color=BLUE, lw=1.4, label=r"baseline $p^{b}$"), Patch(color="#f3ead2", label="priced hours")]
    fig.legend(handles=hnd, loc="upper center", ncol=4, bbox_to_anchor=(0.5, 1.04))
    fig.tight_layout(); save(fig, "fig_oprange.pdf")


def fig_coopt():
    rhos = [0, 5, 10, 20]; meths = ["Robust_DDU", "DD_CVaR", "Proposed"]
    fig, axs = plt.subplots(2, 2, figsize=(W, 4.5))
    for m in meths:
        col, mk = STYLE[m]
        prof = 1 + _m("33", "coopt", "rho0", m)[1]["sol"]["x"].mean(0)
        axs[0, 0].plot(np.arange(1, 25), prof, marker=mk, color=col, ms=3, label=LABEL[m],
                       ls="--" if m == "Robust_DDU" else "-")
        X, P, F, Flo, Fhi, C, Clo, Chi = [], [], [], [], [], [], [], []
        for rho in rhos:
            mm, r = _m("33", "coopt", f"rho{rho}", m)
            X.append(rho); P.append(1 + r["sol"]["x"].mean())
            F.append(100 * mm["joint_fail"]); Flo.append(100 * mm["joint_fail_ci"][0]); Fhi.append(100 * mm["joint_fail_ci"][1])
            C.append(mm["total"]); Clo.append(mm["total_ci"][0]); Chi.append(mm["total_ci"][1])
        F, C = np.array(F), np.array(C)
        Xd = np.array(X) + {"Robust_DDU": -0.45, "DD_CVaR": 0.0, "Proposed": 0.45}[m]
        axs[0, 1].plot(X, P, "-" + mk, color=col, ms=4)
        axs[1, 0].errorbar(Xd, F, yerr=[F - Flo, np.array(Fhi) - F], fmt="-" + mk, color=col, ms=4, capsize=2)
        axs[1, 1].errorbar(Xd, C, yerr=[C - Clo, np.array(Chi) - C], fmt="-" + mk, color=col, ms=4, capsize=2)
    refs = []
    for ref, ls in (("SAA_CVaR", ":"), ("Exo_Winf", "--")):
        mm, _ = _m("33", "coopt", "rho5", ref); col, _mk = STYLE[ref]
        axs[1, 0].axhline(100 * mm["joint_fail"], color=col, ls=ls, lw=1.1)
        axs[1, 1].axhline(mm["total"], color=col, ls=ls, lw=1.1)
        refs.append(Line2D([], [], color=col, ls=ls, lw=1.1, label=LABEL[ref] + r", $\pi=1$"))
    axs[1, 0].axhline(10, color=GREY, lw=0.9, ls="-.")
    axs[0, 0].set_xlabel("hour"); axs[0, 0].set_ylabel(r"price ratio $\pi$, mean over EVAs"); axs[0, 0].set_xlim(0.5, 24.5)
    axs[0, 0].set_title(r"(a) prices chosen at $\rho^{\mathrm{inc}}=0$", loc="left")
    axs[0, 1].set_ylabel(r"mean price ratio $\pi$"); axs[0, 1].set_title("(b) price level", loc="left")
    axs[1, 0].set_ylabel("system failure (%)"); axs[1, 0].set_title("(c) reliability", loc="left")
    axs[1, 1].set_ylabel("total cost (\\$)"); axs[1, 1].set_title("(d) total cost", loc="left")
    for ax in (axs[0, 1], axs[1, 0], axs[1, 1]):
        ax.set_xlabel(r"incentive rate $\rho^{\mathrm{inc}}$ (\$/MWh)"); ax.set_xticks(rhos)
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h + refs + [TARGET], l + [r.get_label() for r in refs] + ["target 10%"], loc="upper center",
               ncol=3, bbox_to_anchor=(0.5, 1.07))
    fig.tight_layout(h_pad=1.2, w_pad=1.6); save(fig, "fig_coopt.pdf")


def fig_conserv():
    xs = [0.1, 0.2, 0.3, 0.4, 0.5]
    series = [("Proposed_P1", "outer ball, Proposition 1", GREEN, "D", lambda x: f"x{x}"),
              ("Proposed", "exact set, Proposition 2 (M7)", BLUE, "o", lambda x: "grideps0.000" if x == 0.5 else f"x{x}"),
              ("DD_CVaR", "nominal response (M6)", DARK, "^", lambda x: "main" if x == 0.5 else f"x{x}"),
              ("SAA_CVaR", "price-blind (M2)", GREY, "v", lambda x: "main" if x == 0.5 else f"x{x}")]
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.6))
    for meth, lab, col, mk, tagf in series:
        X, F, Flo, Fhi, C = [], [], [], [], []
        for x in xs:
            mm, _ = _m("33", "fixed", tagf(x), meth)
            X.append(1 + x); F.append(100 * mm["joint_fail"]); Flo.append(100 * mm["joint_fail_ci"][0])
            Fhi.append(100 * mm["joint_fail_ci"][1]); C.append(mm["total"])
        F = np.array(F); off = {"Proposed_P1": -0.012, "Proposed": -0.004, "DD_CVaR": 0.004, "SAA_CVaR": 0.012}[meth]
        axs[0].plot(X, C, "-" + mk, color=col, ms=4, label=lab)
        axs[1].errorbar(np.array(X) + off, F, yerr=[F - Flo, np.array(Fhi) - F], fmt="-" + mk, color=col, ms=4, capsize=2)
    axs[1].axhline(10, color=GREY, lw=0.9, ls="-.")
    for ax in axs:
        ax.set_xlabel(r"price ratio $\pi$ in hours 9 to 15")
    axs[0].set_ylabel("total cost (\\$)"); axs[0].set_title("(a) cost", loc="left")
    axs[1].set_ylabel("system failure (%)"); axs[1].set_title("(b) reliability", loc="left")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h + [TARGET], l + ["target 10%"], loc="upper center", ncol=3, bbox_to_anchor=(0.5, 1.12))
    fig.tight_layout(w_pad=2.0); save(fig, "fig_conserv.pdf")


def fig_sens():
    fig, axs = plt.subplots(2, 2, figsize=(W, 4.9))
    B, Fb, Cb = [], [], []
    for b, tag in [(0.0, None), (0.2, "beta0.2"), (0.4, "grideps0.000"), (0.6, "beta0.6"), (0.8, "beta0.8")]:
        mm, _ = _m("33", "fixed", "main", "DD_CVaR") if tag is None else _m("33", "fixed", tag, "Proposed")
        B.append(100 * b); Fb.append(100 * mm["joint_fail"]); Cb.append(mm["total"])
    axs[0, 0].plot(B, Fb, "-o", color=BLUE, ms=4); axs[0, 0].axhline(10, color=GREY, lw=0.9, ls="-.")
    axs[0, 0].set_xlabel(r"sensitivity band $\beta$ (%)"); axs[0, 0].set_ylabel("system failure (%)")
    axs[0, 0].set_title(r"(a) band $\beta$: reliability", loc="left")
    axs[0, 1].plot(B, Cb, "-o", color=BLUE, ms=4)
    axs[0, 1].set_xlabel(r"sensitivity band $\beta$ (%)"); axs[0, 1].set_ylabel("total cost (\\$)")
    axs[0, 1].set_title(r"(b) band $\beta$: cost", loc="left")
    ax = axs[1, 0]
    for meth, lab, col, mk, tags in [("SAA_CVaR", "M2", GREY, "v", {50: "n50", 100: "n100", 300: "main"}),
                                     ("Exo_Winf", r"M4, $\varepsilon=0.05$", GREEN, "D", {50: "n50", 100: "n100", 300: "grideps0.050"}),
                                     ("Proposed", r"M7, $\varepsilon=0$", BLUE, "o", {50: "n50", 100: "n100", 300: "grideps0.000"}),
                                     ("Proposed", r"M7, $\varepsilon=0.025$", ORANGE, "s", {50: "n50e025", 100: "n100e025", 300: "grideps0.025"})]:
        Ns = list(tags); Fs = [100 * _m("33", "fixed", tags[n], meth)[0]["joint_fail"] for n in Ns]
        ax.plot(Ns, Fs, "-" + mk, color=col, ms=4, label=lab)
    ax.axhline(10, color=GREY, lw=0.9, ls="-."); ax.set_xlabel("training days $N$"); ax.set_ylabel("system failure (%)")
    ax.set_title("(c) amount of data", loc="left"); ax.set_xticks([50, 100, 300])
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.24), ncol=2)
    ax = axs[1, 1]
    mt = [("SAA_CVaR", "main"), ("DD_CVaR", "main"), ("Robust_DDU", "main"), ("Exo_Winf", "grideps0.050"), ("Proposed", "grideps0.000")]
    hets = (0.0, 0.2, 0.4, 0.6, 0.8)
    res = json.load(open(RES / "het_eval.json")) if (RES / "het_eval.json").exists() else None
    for meth, _t in mt:
        col, mk = STYLE[meth]
        ys = [100 * res[f"{meth}|{h}"][0] for h in hets]
        ax.plot([100 * h for h in hets], ys, "-" + mk, color=col, ms=4, label=LABEL[meth])
    ax.axhline(10, color=GREY, lw=0.9, ls="-."); ax.set_xlabel(r"heterogeneity of the true response, $\pm$ (%)")
    ax.set_ylabel("system failure (%)"); ax.set_title("(d) response heterogeneity", loc="left")
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.24), ncol=3, columnspacing=0.8)
    fig.tight_layout(h_pad=1.0, w_pad=2.0); save(fig, "fig_sens.pdf")


def fig_conv():
    sys.path.insert(0, str(HERE)); import select_v2 as S
    fig, axs = plt.subplots(1, 2, figsize=(W, 2.4))
    for ax, sname in zip(axs, ["33", "123"]):
        tag, _ = S.select(sname, "fixed", "Proposed")
        lg = S.load(sname, "fixed", tag, "Proposed")["log"]
        it = np.array(lg["it"]); LB = np.array(lg["LB"]); UB = np.array(lg["UB"])
        ax.plot(it, UB, "-o", color=ORANGE, ms=3.5, label="upper bound")
        ax.plot(it, LB, "--s", color=BLUE, ms=3.5, label="lower bound")
        ax.set_yscale("log"); ax.set_xlabel("iteration"); ax.set_ylabel("objective (\\$)")
        gap = 100 * (UB[-1] - LB[-1]) / UB[-1]
        ax.set_title(f"({'a' if sname == '33' else 'b'}) IEEE {sname}-bus: gap {gap:.2f}%, {lg['t'][-1]:.0f} s", loc="left")
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=2, bbox_to_anchor=(0.5, 1.07))
    fig.tight_layout(w_pad=2.0); save(fig, "fig_conv.pdf")


if __name__ == "__main__":
    FIG.mkdir(parents=True, exist_ok=True)
    which = sys.argv[1:] or ["profiles", "response", "tradeoff", "oprange", "coopt", "conserv", "sens", "conv"]
    for w in which:
        globals()[f"fig_{w}"]()
