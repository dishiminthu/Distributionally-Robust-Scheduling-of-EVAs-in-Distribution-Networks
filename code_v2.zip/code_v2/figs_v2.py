"""figs_v2.py -- figures of the revision (matplotlib -> ../figures/*.pdf).

Palette: validated reference slots 1-3 (blue #2a78d6, orange #eb6834, green #1baf7a)
plus neutral greys; every series also has its own marker/line style, one y-axis
per panel, legends on every multi-series panel.
"""
import json, sys
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

HERE = Path(__file__).resolve().parent
FIG = HERE.parent / "figures"; RES = HERE.parent / "results_v2"
BLUE, ORANGE, GREEN, GREY, DARK = "#2a78d6", "#eb6834", "#1baf7a", "#8c8c8c", "#333333"
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"],
                     "mathtext.fontset": "stix", "font.size": 8, "axes.labelsize": 8, "legend.fontsize": 7,
                     "xtick.labelsize": 7, "ytick.labelsize": 7, "axes.spines.top": False,
                     "axes.spines.right": False, "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": 0.5,
                     "lines.linewidth": 1.4, "savefig.bbox": "tight", "savefig.pad_inches": 0.02})


def fig_response():
    b = json.load(open(RES / "behaviour_summary.json"))
    x = np.array(b["bins"]); v2g = 100 * np.array(b["plugged_v2g_share"]); g2v = 100 * np.array(b["plugged_g2v_share"])
    fig, ax = plt.subplots(1, 2, figsize=(7.0, 2.4))
    a = ax[0]
    a.plot(x, g2v, "-o", color=BLUE, ms=3.5, label="G2V recommended")
    a.plot(x, v2g, "--s", color=ORANGE, ms=3.5, label="V2G recommended")
    a.axvline(1.0, color=GREY, lw=0.8, ls=":")
    a.set_xlabel(r"price ratio $\pi$ (bin centre)"); a.set_ylabel("share of plugged-in records (%)")
    a.set_ylim(-3, 103); a.set_title("(a) dataset: threshold rule", loc="left", fontsize=8)
    a.legend(loc="upper right", frameon=False)
    a = ax[1]
    pi = np.linspace(1.0, 1.5, 101); xx = pi - 1
    Sc, Sd, chi, beta, dc, dd = 0.30, 0.40, 0.5, 0.4, 0.25, 0.25
    for (nom, lo, hi, tl, th, col, mk, lab) in [
        (1 - Sc * xx, 1 - Sc * (1 + beta) * xx, 1 - Sc * (1 - beta) * xx,
         1 - 1.4 * dc * np.tanh(Sc * xx / dc), 1 - 0.6 * dc * np.tanh(Sc * xx / dc), BLUE, "o", "charging share $c(\\pi)$"),
        (chi + Sd * xx, chi + Sd * (1 - beta) * xx, chi + Sd * (1 + beta) * xx,
         chi + 0.6 * dd * np.tanh(Sd * xx / dd), chi + 1.4 * dd * np.tanh(Sd * xx / dd), ORANGE, "s", "V2G share $d(\\pi)$")]:
        a.fill_between(pi, lo, hi, color=col, alpha=0.12, lw=0)
        a.plot(pi, nom, "-", color=col, label=f"{lab}: model (nominal)")
        a.plot(pi, tl, ":", color=col, lw=1.0); a.plot(pi, th, ":", color=col, lw=1.0)
        a.plot(pi[::25], nom[::25], mk, color=col, ms=3.5)
    a.plot([], [], color=GREY, alpha=0.4, lw=6, label=r"model band $\pm40\%$")
    a.plot([], [], ":", color=GREY, label="true response, range over sites/days")
    a.set_xlabel(r"price ratio $\pi$"); a.set_ylabel("share of connected capacity")
    a.set_title("(b) response used in the case study", loc="left", fontsize=8)
    a.legend(loc="center left", bbox_to_anchor=(1.01, 0.5), frameon=False)
    fig.tight_layout(); fig.savefig(FIG / "fig_response_v2.pdf"); plt.close(fig)
    print("saved fig_response_v2.pdf")


LABEL = {"DET": "M1 DET", "SAA_CVaR": "M2 SAA-CVaR", "Moment_DRO": "M3 Moment-DRO", "Exo_Winf": "M4 Exo-W$_\\infty$",
         "Robust_DDU": "M5 Robust-DDU", "DD_CVaR": "M6 DD-CVaR", "Proposed": "M7 Proposed"}
STYLE = {"SAA_CVaR": (GREY, "v"), "Exo_Winf": (GREEN, "D"), "Robust_DDU": (ORANGE, "s"),
         "DD_CVaR": (DARK, "^"), "Proposed": (BLUE, "o")}


def fig_tradeoff():
    import select_v2 as S
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.6))
    for ax, sname in zip(axs, ["33", "123"]):
        rows, _ = S.table(sname, "fixed")
        ref = rows["Proposed"]["total"]
        for m in ["SAA_CVaR", "Exo_Winf", "Robust_DDU", "DD_CVaR", "Proposed"]:
            r = rows[m]; col, mk = STYLE[m]
            xv = 100 * r["joint_fail"]; xl, xh = 100 * np.array(r["joint_fail_ci"])
            yv = 100 * (r["total"] / ref - 1); yl, yh = 100 * (np.array(r["total_ci"]) / ref - 1)
            ax.errorbar(xv, yv, xerr=[[xv - xl], [xh - xv]], yerr=[[yv - yl], [yh - yv]], fmt=mk, color=col,
                        ms=5, mfc=col, mec="white", mew=0.6, elinewidth=0.9, capsize=2, label=LABEL[m])
        ax.axvline(10, color=GREY, ls="--", lw=0.9); ax.axhline(0, color=GREY, lw=0.6)
        ax.text(10.6, 0.03, "target 10%", transform=ax.get_xaxis_transform(), fontsize=6.5, color=GREY, va="bottom")
        ax.set_xlabel("system failure probability on test days (%)")
        ax.set_ylabel("total cost vs. M7 (%)")
        ax.set_title(f"({'a' if sname == '33' else 'b'}) IEEE {sname}-bus, $\\pi=1.5$ in hours 9--15", loc="left", fontsize=8)
        ax.set_xlim(0, 36)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=5, frameon=False, bbox_to_anchor=(0.5, 1.06))
    fig.tight_layout(); fig.savefig(FIG / "fig_tradeoff_v2.pdf"); plt.close(fig); print("saved fig_tradeoff_v2.pdf")


def fig_conv():
    import select_v2 as S
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.2))
    for ax, sname in zip(axs, ["33", "123"]):
        tag, _ = S.select(sname, "fixed", "Proposed")
        lg = S.load(sname, "fixed", tag, "Proposed")["log"]
        it = np.array(lg["it"]); LB = np.array(lg["LB"]); UB = np.array(lg["UB"])
        ax.plot(it, UB, "-o", color=ORANGE, ms=3.5, label="upper bound (exact evaluation)")
        ax.plot(it, LB, "--s", color=BLUE, ms=3.5, label="lower bound (master MIP bound)")
        ax.set_yscale("log"); ax.set_xlabel("iteration"); ax.set_ylabel("objective (\\$)")
        a2 = ax.twinx() if False else None
        ax.set_title(f"({'a' if sname == '33' else 'b'}) IEEE {sname}-bus, M7", loc="left", fontsize=8)
        for i_, (u_, l_) in enumerate(zip(UB, LB)):
            pass
        ax.text(0.98, 0.95, f"final gap {100*(UB[-1]-LB[-1])/UB[-1]:.2f}%\n{lg['npieces'][-1]} pieces, {lg['t'][-1]:.0f} s",
                transform=ax.transAxes, ha="right", va="top", fontsize=6.5)
        ax.legend(loc="center right", frameon=False)
    fig.tight_layout(); fig.savefig(FIG / "fig_conv_v2.pdf"); plt.close(fig); print("saved fig_conv_v2.pdf")


def fig_oprange():
    import select_v2 as S, model_v2 as M, run_v2 as R
    tag, _ = S.select("33", "fixed", "Proposed")
    sol = S.load("33", "fixed", tag, "Proposed")["sol"]
    c = R.case_for("33"); a = c["ev_avail"]; Pm = c["ev_Pmax"]; x = sol["x"]
    Sc, Sd, chi = c["S_ch"], c["S_dis"], c["chi"]
    hi = a * Pm[:, None] * (1 - Sc * x); lo = -a * Pm[:, None] * (chi + Sd * x)
    pb = sol["pch"] - sol["pdis"]
    t = np.arange(1, 25)
    names = ["EVA1 residential (bus 18)", "EVA2 residential (bus 22)", "EVA3 commercial (bus 25)", "EVA4 workplace (bus 33)"]
    fig, axs = plt.subplots(2, 2, figsize=(7.0, 4.0), sharex=True)
    for k, ax in enumerate(axs.ravel()):
        ax.axvspan(8.5, 15.5, color="#f3ead2", lw=0, zorder=0)
        ax.fill_between(t, lo[k], hi[k], step="mid", color=GREY, alpha=0.18, lw=0, label="forecast operating range")
        ax.fill_between(t, pb[k] - sol["rdn"][k], pb[k] + sol["rup"][k], step="mid", color=GREEN, alpha=0.35, lw=0,
                        label="reserve band")
        ax.step(t, pb[k], where="mid", color=BLUE, lw=1.4, label="baseline $p^b$")
        ax.axhline(0, color=GREY, lw=0.6)
        ax.set_title(names[k], loc="left", fontsize=8); ax.set_xlim(0.5, 24.5)
        if k % 2 == 0:
            ax.set_ylabel("MW")
        if k >= 2:
            ax.set_xlabel("hour")
    h, l = axs[0, 0].get_legend_handles_labels()
    fig.legend(h, l, loc="upper center", ncol=3, frameon=False, bbox_to_anchor=(0.5, 1.03))
    fig.tight_layout(); fig.savefig(FIG / "fig_oprange_v2.pdf"); plt.close(fig); print("saved fig_oprange_v2.pdf")



def _m(sname, exp, tag, meth):
    import select_v2 as S
    r = S.load(sname, exp, tag, meth)
    return None if r is None else (S.metrics(r), r)


def fig_coopt():
    rhos = [0, 5, 10, 20]
    meths = ["Robust_DDU", "DD_CVaR", "Proposed"]
    fig, axs = plt.subplots(2, 2, figsize=(7.0, 4.4))
    # (a) hourly price at rho = 0
    ax = axs[0, 0]
    for m in meths:
        mm, r = _m("33", "coopt", "rho0", m); col, mk = STYLE[m]
        prof = 1 + r["sol"]["x"].mean(0)
        ax.plot(np.arange(1, 25), prof, "-" + mk, color=col, ms=3, label=LABEL[m])
    ax.set_xlabel("hour"); ax.set_ylabel(r"mean price ratio $\pi$ over EVAs"); ax.set_xlim(0.5, 24.5)
    ax.set_title(r"(a) chosen prices, $\rho^{\mathrm{inc}}=0$", loc="left", fontsize=8)
    # (b)-(d) vs rho
    for m in meths:
        col, mk = STYLE[m]
        X, F, Flo, Fhi, Cc, Clo, Chi = [], [], [], [], [], [], []
        for rho in rhos:
            got = _m("33", "coopt", f"rho{rho}", m)
            if got is None:
                continue
            mm, r = got
            X.append(rho); xs = r["sol"]["x"]; F.append(100 * mm["joint_fail"])
            Flo.append(100 * mm["joint_fail_ci"][0]); Fhi.append(100 * mm["joint_fail_ci"][1])
            Cc.append(mm["total"]); Clo.append(mm["total_ci"][0]); Chi.append(mm["total_ci"][1])
        X = np.array(X)
        xbar = [1 + _m("33", "coopt", f"rho{rho}", m)[1]["sol"]["x"].mean() for rho in X]
        axs[0, 1].plot(X, xbar, "-" + mk, color=col, ms=4, label=LABEL[m])
        axs[1, 0].errorbar(X, F, yerr=[np.array(F) - Flo, np.array(Fhi) - F], fmt="-" + mk, color=col, ms=4, capsize=2, label=LABEL[m])
        axs[1, 1].errorbar(X, Cc, yerr=[np.array(Cc) - Clo, np.array(Chi) - Cc], fmt="-" + mk, color=col, ms=4, capsize=2, label=LABEL[m])
    for ref, ls in (("SAA_CVaR", ":"), ("Exo_Winf", "--")):
        got = _m("33", "coopt", "rho5", ref)
        if got:
            mm, _ = got; col, _mk = STYLE[ref]
            axs[1, 0].axhline(100 * mm["joint_fail"], color=col, ls=ls, lw=1, label=LABEL[ref] + r" ($\pi=1$)")
            axs[1, 1].axhline(mm["total"], color=col, ls=ls, lw=1, label=LABEL[ref] + r" ($\pi=1$)")
    axs[0, 1].set_xlabel(r"incentive rate $\rho^{\mathrm{inc}}$ (\$/MWh per unit $x$)"); axs[0, 1].set_ylabel(r"mean $\pi$ over EVA-hours")
    axs[0, 1].set_title("(b) price level", loc="left", fontsize=8)
    axs[1, 0].axhline(10, color=GREY, lw=0.8, ls="-."); axs[1, 0].set_ylabel("system failure (%)")
    axs[1, 0].set_xlabel(r"incentive rate $\rho^{\mathrm{inc}}$"); axs[1, 0].set_title("(c) out-of-sample reliability", loc="left", fontsize=8)
    axs[1, 1].set_ylabel("total cost (\\$)"); axs[1, 1].set_xlabel(r"incentive rate $\rho^{\mathrm{inc}}$")
    axs[1, 1].set_title("(d) total cost", loc="left", fontsize=8)
    axs[0, 0].legend(frameon=False, loc="upper left")
    h, l = axs[1, 0].get_legend_handles_labels()
    axs[1, 1].legend(h, l, frameon=False, fontsize=6.5, loc="center right")
    fig.tight_layout(); fig.savefig(FIG / "fig_coopt_v2.pdf"); plt.close(fig); print("saved fig_coopt_v2.pdf")


def fig_conserv():
    xs = [0.1, 0.2, 0.3, 0.4, 0.5]
    fig, axs = plt.subplots(1, 2, figsize=(7.0, 2.4))
    series = [("Proposed_P1", "outer ball (Prop. 1)", GREEN, "D", lambda x: f"x{x}"),
              ("Proposed", "exact set (Prop. 2), M7", BLUE, "o", lambda x: "grideps0.000" if x == 0.5 else f"x{x}"),
              ("DD_CVaR", "nominal response, M6", DARK, "^", lambda x: "main" if x == 0.5 else f"x{x}"),
              ("SAA_CVaR", "price-blind, M2", GREY, "v", lambda x: "main" if x == 0.5 else f"x{x}")]
    for meth, lab, col, mk, tagf in series:
        X, F, Flo, Fhi, Cc = [], [], [], [], []
        for x in xs:
            got = _m("33", "fixed", tagf(x), meth)
            if got is None:
                continue
            mm, _ = got
            X.append(1 + x); F.append(100 * mm["joint_fail"]); Flo.append(100 * mm["joint_fail_ci"][0])
            Fhi.append(100 * mm["joint_fail_ci"][1]); Cc.append(mm["total"])
        if not X:
            continue
        axs[0].plot(X, Cc, "-" + mk, color=col, ms=4, label=lab)
        axs[1].errorbar(X, F, yerr=[np.array(F) - Flo, np.array(Fhi) - F], fmt="-" + mk, color=col, ms=4, capsize=2, label=lab)
    axs[0].set_xlabel(r"incentive price ratio $\pi$ in hours 9--15"); axs[0].set_ylabel("total cost (\\$)")
    axs[0].set_title("(a) cost", loc="left", fontsize=8)
    axs[1].axhline(10, color=GREY, lw=0.8, ls="-.")
    axs[1].set_xlabel(r"incentive price ratio $\pi$ in hours 9--15"); axs[1].set_ylabel("system failure (%)")
    axs[1].set_title("(b) out-of-sample reliability", loc="left", fontsize=8)
    axs[0].legend(frameon=False, loc="upper left")
    fig.tight_layout(); fig.savefig(FIG / "fig_conserv_v2.pdf"); plt.close(fig); print("saved fig_conserv_v2.pdf")


def het_eval(meths_tags, hets=(0.0, 0.2, 0.4, 0.6, 0.8)):
    """Re-evaluate stored 33-bus fixed-incentive schedules under other true-response heterogeneity."""
    import select_v2 as S, model_v2 as M, run_v2 as R
    out = {}
    for h in hets:
        c = R.case_for("33", het=h); nd = M.net_data(c)
        for meth, tag in meths_tags:
            sol = S.load("33", "fixed", tag, meth)["sol"]
            e = M.evaluate(c, sol, "test", nd)
            out[(meth, h)] = (float(e["joint_fail"].mean()), float(e["res_fail"].mean()), float(e["net_fail"].mean()))
    return out


def fig_sens():
    import select_v2 as S
    fig, axs = plt.subplots(1, 3, figsize=(7.0, 2.3))
    # (a) band width beta
    B, F, C = [], [], []
    for b, tag in [(0.0, None), (0.2, "beta0.2"), (0.4, "grideps0.000"), (0.6, "beta0.6"), (0.8, "beta0.8")]:
        got = _m("33", "fixed", "main", "DD_CVaR") if tag is None else _m("33", "fixed", tag, "Proposed")
        if got is None:
            continue
        mm, _ = got; B.append(100 * b); F.append(100 * mm["joint_fail"]); C.append(mm["total"])
    ax = axs[0]
    ax.plot(B, F, "-o", color=BLUE, ms=4, label="system failure (%)")
    ax.set_xlabel(r"sensitivity band $\beta$ (%)"); ax.set_ylabel("system failure (%)"); ax.axhline(10, color=GREY, lw=0.8, ls="-.")
    for b_, f_, c_ in zip(B, F, C):
        ax.annotate(f"{c_:.0f}\\$", (b_, f_), textcoords="offset points", xytext=(0, 5), ha="center", fontsize=6)
    ax.set_title(r"(a) band $\beta$ (labels: total cost)", loc="left", fontsize=8)
    # (b) training days
    ax = axs[1]
    for meth, lab, col, mk, tags in [("SAA_CVaR", "M2", GREY, "v", {50: "n50", 100: "n100", 300: "main"}),
                                     ("Exo_Winf", r"M4, $\varepsilon=0.05$", GREEN, "D", {50: "n50", 100: "n100", 300: "grideps0.050"}),
                                     ("Proposed", r"M7, $\varepsilon=0$", BLUE, "o", {50: "n50", 100: "n100", 300: "grideps0.000"}),
                                     ("Proposed", r"M7, $\varepsilon=0.025$", ORANGE, "s", {50: "n50e025", 100: "n100e025", 300: "grideps0.025"})]:
        Ns, Fs = [], []
        for n, tag in tags.items():
            got = _m("33", "fixed", tag, meth)
            if got:
                Ns.append(n); Fs.append(100 * got[0]["joint_fail"])
        ax.plot(Ns, Fs, "-" + mk, color=col, ms=4, label=lab)
    ax.axhline(10, color=GREY, lw=0.8, ls="-."); ax.set_xlabel("training days $N$"); ax.set_ylabel("system failure (%)")
    ax.set_title("(b) data size", loc="left", fontsize=8); ax.legend(frameon=False, fontsize=6)
    # (c) heterogeneity of the true response (evaluation only)
    ax = axs[2]
    mt = [("SAA_CVaR", "main"), ("DD_CVaR", "main"), ("Robust_DDU", "main"), ("Exo_Winf", "grideps0.050"), ("Proposed", "grideps0.000")]
    hets = (0.0, 0.2, 0.4, 0.6, 0.8)
    res = het_eval(mt, hets)
    for meth, _t in mt:
        col, mk = STYLE[meth]
        ax.plot([100 * h for h in hets], [100 * res[(meth, h)][0] for h in hets], "-" + mk, color=col, ms=4, label=LABEL[meth])
    ax.axhline(10, color=GREY, lw=0.8, ls="-."); ax.set_xlabel(r"heterogeneity of true response $\pm$ (%)")
    ax.set_ylabel("system failure (%)"); ax.set_title("(c) response heterogeneity", loc="left", fontsize=8)
    ax.set_ylim(0, 48); ax.legend(frameon=False, fontsize=6, loc="upper left", ncol=2)
    fig.tight_layout(); fig.savefig(FIG / "fig_sens_v2.pdf"); plt.close(fig); print("saved fig_sens_v2.pdf")
    json.dump({f"{k[0]}|{k[1]}": v for k, v in res.items()}, open(RES / "het_eval.json", "w"), indent=1)


if __name__ == "__main__":
    which = sys.argv[1:] or ["response"]
    for w in which:
        globals()[f"fig_{w}"]()
