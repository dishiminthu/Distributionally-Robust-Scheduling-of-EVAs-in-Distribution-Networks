#!/bin/zsh
# price co-optimisation on the 33-bus feeder (all hours priceable); radii from the fixed-incentive selection
cd "$(dirname "$0")"
for rho in 0 5 10 20; do
  python3 experiments_v2.py 33 coopt Robust_DDU --eps 0 --allhours --rho_inc $rho --tag rho$rho --threads 2
  python3 experiments_v2.py 33 coopt DD_CVaR   --eps 0 --allhours --rho_inc $rho --tag rho$rho --threads 2
  python3 experiments_v2.py 33 coopt Proposed  --eps 0 --allhours --rho_inc $rho --tag rho$rho --threads 2
done
python3 experiments_v2.py 33 coopt SAA_CVaR --eps 0 --allhours --rho_inc 5 --tag rho5 --threads 2
python3 experiments_v2.py 33 coopt Exo_Winf --eps 0.05 --allhours --rho_inc 5 --tag rho5 --threads 2
