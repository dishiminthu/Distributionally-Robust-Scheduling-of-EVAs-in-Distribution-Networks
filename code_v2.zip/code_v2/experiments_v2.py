"""experiments_v2.py -- experiment grid of the revision (one call = one block).

  python experiments_v2.py <sys> <exp> untuned        # DET, SAA_CVaR, Moment_DRO, Robust_DDU, DD_CVaR
  python experiments_v2.py <sys> <exp> Exo_Winf       # radius grid, selected later on validation
  python experiments_v2.py <sys> <exp> Proposed
  python experiments_v2.py <sys> <exp> <method> --eps 0.05 --tag xyz [--beta ..] [--xfix ..] [--rho_inc ..]

Every method uses all 300 training days, the same algorithm, MIP gap and time
limits.  The radius of the two W_inf methods is chosen afterwards from the grid
on the 65 validation days (select_v2.py); the test days are never used for tuning.
"""
import argparse
import model_v2 as M
import run_v2 as R

GRID = [0.0, 0.025, 0.05, 0.075, 0.10]
UNTUNED = ["DET", "SAA_CVaR", "Moment_DRO", "Robust_DDU", "DD_CVaR"]

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("sys"); ap.add_argument("exp"); ap.add_argument("block")
    ap.add_argument("--eps", type=float, default=None); ap.add_argument("--tag", default=None)
    ap.add_argument("--beta", type=float, default=0.4); ap.add_argument("--xfix", type=float, default=0.5)
    ap.add_argument("--rho_inc", type=float, default=20.0); ap.add_argument("--threads", type=int, default=4)
    ap.add_argument("--time_limit", type=float, default=120); ap.add_argument("--het", type=float, default=None)
    ap.add_argument("--vband", type=float, default=None); ap.add_argument("--ntrain", type=int, default=None)
    ap.add_argument("--allhours", action="store_true"); ap.add_argument("--cdeg", type=float, default=None)
    a = ap.parse_args()
    base = M.default_pars(threads=a.threads, time_limit=a.time_limit, beta=a.beta, rho_inc=a.rho_inc, n_add=4)
    over = {}
    if a.het is not None:
        over["het"] = a.het
    if a.vband is not None:
        over["vband"] = a.vband
    if a.ntrain is not None:
        over["ntrain"] = a.ntrain
    if a.allhours:
        over["allhours"] = True
    if a.cdeg is not None:
        over["cdeg"] = a.cdeg
    if a.block == "untuned":
        R.run(a.sys, a.exp, UNTUNED, base, a.tag or "main", xfix=a.xfix, case_over=over, quiet=True)
    elif a.eps is None:
        for e in GRID:
            R.run(a.sys, a.exp, [a.block], dict(base, eps=e), f"{a.tag or 'grid'}eps{e:.3f}",
                  xfix=a.xfix, case_over=over, quiet=True)
    else:
        R.run(a.sys, a.exp, [a.block], dict(base, eps=a.eps), a.tag or f"eps{a.eps:.3f}",
              xfix=a.xfix, case_over=over, quiet=True)
