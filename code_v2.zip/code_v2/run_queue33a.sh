#!/bin/zsh
# remaining 33-bus studies (fixed incentive unless stated); radii: Proposed 0, Exo 0.05
cd "$(dirname "$0")"
E() { python3 experiments_v2.py 33 "$@"; }
for x in 0.1 0.2 0.3 0.4 0.5; do
  E fixed Proposed_P1 --eps 0 --xfix $x --tag x$x --threads 3
  [ "$x" != "0.5" ] && E fixed Proposed --eps 0 --xfix $x --tag x$x --threads 3
  [ "$x" != "0.5" ] && E fixed DD_CVaR --eps 0 --xfix $x --tag x$x --threads 3
  [ "$x" != "0.5" ] && E fixed SAA_CVaR --eps 0 --xfix $x --tag x$x --threads 3
done
