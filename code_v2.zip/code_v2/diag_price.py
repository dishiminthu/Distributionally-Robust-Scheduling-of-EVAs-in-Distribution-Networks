import sys, numpy as np, model_v2 as M, run_v2 as R
c = R.case_for(sys.argv[1]); nd = M.net_data(c)
meth = sys.argv[2]
for rho in map(float, sys.argv[3:]):
    pars = M.default_pars(threads=6, n_add=4, rho_inc=rho, eps=0.05)
    sol, log = M.solve(c, meth, pars, x_fixed=None, log_fn=lambda s: None)
    s = M.summarize(M.evaluate(c, sol, "test", nd))
    W = c["W"]; xw = sol["x"][:, W]
    print(f"{meth} rho_inc={rho:5.1f}: econ {sol['econ']:.1f} cinc {sol['cinc']:.1f} | x by EVA (mean over window) {np.round(xw.mean(1),3)} "
          f"| test p_net {s['p_net']:.3f} p_res {s['p_res']:.3f} p_joint {s['p_joint']:.3f} total {s['total']:.1f} | it {len(log['it'])} t {log['time_s']:.0f}s", flush=True)
    print("   pdis in window by EVA:", np.round(sol["pdis"][:, W].sum(1), 3), " rdn:", np.round(sol["rdn"][:, W].sum(1), 3), " rup:", np.round(sol["rup"][:, W].sum(1), 3))
