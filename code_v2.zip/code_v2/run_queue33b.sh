#!/bin/zsh
cd "$(dirname "$0")"
E() { python3 experiments_v2.py 33 "$@"; }
for b in 0.2 0.6 0.8; do E fixed Proposed --eps 0 --beta $b --tag beta$b --threads 3; done
for n in 50 100; do
  E fixed SAA_CVaR --eps 0 --ntrain $n --tag n$n --threads 3
  E fixed Exo_Winf --eps 0.05 --ntrain $n --tag n$n --threads 3
  E fixed Proposed --eps 0 --ntrain $n --tag n$n --threads 3
  E fixed Proposed --eps 0.025 --ntrain $n --tag n${n}e025 --threads 3
done
for m in SAA_CVaR Robust_DDU DD_CVaR; do E fixed $m --eps 0 --vband 0.05 --tag vb5 --threads 3; done
E fixed Exo_Winf --eps 0.05 --vband 0.05 --tag vb5 --threads 3
E fixed Proposed --eps 0 --vband 0.05 --tag vb5 --threads 3
E coopt Proposed --eps 0 --allhours --rho_inc 5 --cdeg 40 --tag rho5cdeg40 --threads 3
E coopt DD_CVaR --eps 0 --allhours --rho_inc 5 --cdeg 40 --tag rho5cdeg40 --threads 3
