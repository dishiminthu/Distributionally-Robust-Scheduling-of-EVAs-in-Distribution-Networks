"""run_v2.py -- run one configuration of the corrected model and store results.

Usage
  python run_v2.py --sys 33 --exp fixed --methods DET SAA_CVaR ... [--eps 0.05] [--tag base]
  --exp fixed : pi = 1 + xfix in the DR window for every method (default xfix = 0.5)
  --exp coopt : every method chooses pi in [1, 1 + x_max] in the DR window

Writes ../results_v2/<sys>_<exp>_<tag>_<method>.npz (solution, C&CG log and the
per-day validation/test outcomes) and prints a one-line summary per method.
"""
import argparse, json, time
from pathlib import Path
import numpy as np
import model_v2 as M

CASES = {"33": dict(npz="case_inputs.npz", load_scale=1.728, vband=0.03),
         "123": dict(npz="case_inputs_123.npz", load_scale=1.0, vband=0.03)}
OUT = Path(__file__).resolve().parents[1] / "results_v2"


def case_for(sysname, **over):
    kw = dict(CASES[sysname]); kw.update(over)
    return M.prepare(kw.pop("npz"), **kw)


def run(sysname, exp, methods, pars, tag, xfix=0.5, case_over=None, quiet=False, over_write=False):
    c = case_for(sysname, **(case_over or {}))
    OUT.mkdir(exist_ok=True)
    K = len(c["eva_buses"]); T = int(c["T"])
    xf = None
    if exp == "fixed":
        xf = np.zeros((K, T)); xf[:, c["W"]] = xfix
    nd = M.net_data(c); rows = []
    for meth in methods:
        p = dict(pars)
        if (OUT / f"{sysname}_{exp}_{tag}_{meth}.npz").exists() and not over_write:
            print(f"[{sysname}/{exp}/{tag}] {meth}: exists, skipped"); continue
        sol, log = M.solve(c, meth, p, x_fixed=xf, log_fn=(lambda s: None) if quiet else print)
        if sol is None:
            print(f"[{sysname}/{exp}/{tag}] {meth}: NO SOLUTION"); continue
        evs = {sp: M.evaluate(c, sol, sp, nd) for sp in ("valid", "test")}
        summ = {sp: M.summarize(e) for sp, e in evs.items()}
        np.savez(OUT / f"{sysname}_{exp}_{tag}_{meth}.npz",
                 sol=np.array(sol, dtype=object), log=np.array(log, dtype=object),
                 pars=np.array(p, dtype=object), case_over=np.array(case_over or {}, dtype=object),
                 **{f"{sp}_{k}": v for sp, e in evs.items() for k, v in e.items() if isinstance(v, np.ndarray)},
                 summary=json.dumps(summ))
        s = summ["test"]; v = summ["valid"]
        gap = (log["UB"][-1] - log["LB"][-1]) / max(abs(log["UB"][-1]), 1.0)
        print(f"[{sysname}/{exp}/{tag}] {meth:11s} eps={sol['eps']:.3f} econ {sol['econ']:8.1f} settled {s['settled']:8.1f} "
              f"total {s['total']:8.1f} | test p_net {s['p_net']:.3f} p_res {s['p_res']:.3f} p_joint {s['p_joint']:.3f} "
              f"undel {s['undel_kWh']:6.1f} kWh | valid p_joint {v['p_joint']:.3f} | x_mean {sol['x'][:, c['W']].mean():.3f} "
              f"| it {len(log['it'])} gap {100*gap:.2f}% t {log['time_s']:.0f}s cn {sol.get('cnet_true',0):.2e} cr {sol.get('cres_true',0):.2e}",
              flush=True)
        rows.append(dict(method=meth, **{f"test_{k}": v for k, v in s.items()},
                         **{f"valid_{k}": v for k, v in summ["valid"].items()},
                         econ=sol["econ"], time_s=log["time_s"], iters=len(log["it"]), gap=gap))
    return rows


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--sys", default="33"); ap.add_argument("--exp", default="fixed")
    ap.add_argument("--methods", nargs="+", default=M.METHODS[:-1])
    ap.add_argument("--eps", type=float, default=0.05); ap.add_argument("--beta", type=float, default=0.4)
    ap.add_argument("--rho_inc", type=float, default=20.0); ap.add_argument("--xfix", type=float, default=0.5)
    ap.add_argument("--threads", type=int, default=4); ap.add_argument("--tag", default="base")
    ap.add_argument("--time_limit", type=float, default=120); ap.add_argument("--max_iter", type=int, default=30)
    ap.add_argument("--n_add", type=int, default=3); ap.add_argument("--quiet", action="store_true")
    a = ap.parse_args()
    pars = M.default_pars(eps=a.eps, beta=a.beta, rho_inc=a.rho_inc, threads=a.threads,
                          time_limit=a.time_limit, max_iter=a.max_iter, n_add=a.n_add)
    t0 = time.time()
    run(a.sys, a.exp, a.methods, pars, a.tag, xfix=a.xfix, quiet=a.quiet)
    print(f"done in {time.time()-t0:.0f}s")
