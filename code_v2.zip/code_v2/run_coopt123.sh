#!/bin/zsh
cd "$(dirname "$0")"
E() { python3 experiments_v2.py 123 coopt "$@"; }
for m in Proposed DD_CVaR Robust_DDU SAA_CVaR; do E $m --eps 0 --allhours --rho_inc 5 --tag rho5 --threads 4 --time_limit 180; done
E Exo_Winf --eps 0.05 --allhours --rho_inc 5 --tag rho5 --threads 4 --time_limit 180
