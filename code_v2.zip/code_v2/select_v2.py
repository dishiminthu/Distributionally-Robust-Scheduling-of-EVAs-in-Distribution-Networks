"""select_v2.py -- validation-based radius selection and result tables.

Selection rule (test days never used): for each tuned method the radius is the
smallest grid value whose VALIDATION system-level failure rate (network OR reserve
failure) is <= 10%; if none qualifies, the radius with the lowest validation
failure rate.  Intervals: Wilson 95% for probabilities (n = 200 test days),
percentile bootstrap (B = 5000) for mean undelivered reserve and total cost.
"""
import glob, json, re
from pathlib import Path
import numpy as np

RES = Path(__file__).resolve().parents[1] / "results_v2"
TARGET = 0.10
RNG = np.random.default_rng(2026)


def wilson(k, n, z=1.959964):
    p = k / n; den = 1 + z * z / n
    ctr = (p + z * z / (2 * n)) / den
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return max(ctr - half, 0.0), min(ctr + half, 1.0)


def boot(x, B=5000):
    idx = RNG.integers(0, len(x), size=(B, len(x)))
    return np.percentile(x[idx].mean(1), [2.5, 97.5])


def load(sysname, exp, tag, method):
    f = RES / f"{sysname}_{exp}_{tag}_{method}.npz"
    if not f.exists():
        return None
    d = np.load(f, allow_pickle=True)
    out = dict(sol=d["sol"].item(), log=d["log"].item(), pars=d["pars"].item(),
               summary=json.loads(str(d["summary"])))
    for k in d.files:
        if k.startswith(("valid_", "test_")):
            out[k] = d[k]
    return out


def grid_tags(sysname, exp, method, prefix="grid"):
    pat = str(RES / f"{sysname}_{exp}_{prefix}eps*_{method}.npz")
    tags = []
    for f in sorted(glob.glob(pat)):
        m = re.search(rf"{sysname}_{exp}_({prefix}eps[0-9.]+)_{method}\.npz", f)
        if m:
            tags.append(m.group(1))
    return tags


def select(sysname, exp, method, prefix="grid"):
    """Return (chosen tag, table of the grid on validation)."""
    rows = []
    for tag in grid_tags(sysname, exp, method, prefix):
        r = load(sysname, exp, tag, method)
        v = r["summary"]["valid"]
        rows.append(dict(tag=tag, eps=float(r["sol"]["eps"]), v_joint=v["p_joint"], v_net=v["p_net"],
                         v_res=v["p_res"], v_total=v["total"]))
    rows.sort(key=lambda z: z["eps"])
    ok = [z for z in rows if z["v_joint"] <= TARGET + 1e-12]
    pick = ok[0] if ok else (min(rows, key=lambda z: (z["v_joint"], z["eps"])) if rows else None)
    return (pick["tag"] if pick else None), rows


def metrics(r, split="test"):
    n = len(r[f"{split}_net_fail"])
    out = dict(n=n)
    for key in ("net_fail", "res_fail", "joint_fail"):
        k = int(r[f"{split}_{key}"].sum()); lo, hi = wilson(k, n)
        out[key] = k / n; out[key + "_ci"] = (lo, hi)
    und = r[f"{split}_undel"]; out["undel_kWh"] = 1e3 * und.mean()
    out["undel_ci"] = tuple(1e3 * boot(und))
    s = r["summary"][split]
    out["settled"] = s["settled"]
    tot = s["settled"] + 1000.0 * und                    # LAMBDA_RT = 1000 $/MWh
    out["total"] = float(tot.mean()); out["total_ci"] = tuple(boot(tot))
    out["econ"] = float(r["sol"]["econ"]); out["time_s"] = float(r["log"]["time_s"])
    out["iters"] = len(r["log"]["it"]); out["eps"] = float(r["sol"]["eps"])
    out["x_mean"] = float(np.mean(r["sol"]["x"][r["sol"]["x"] > 0])) if (r["sol"]["x"] > 0).any() else 0.0
    lb, ub = r["log"]["LB"][-1], r["log"]["UB"][-1]
    out["gap"] = (ub - lb) / max(abs(ub), 1.0)
    out["stats"] = r["sol"].get("stats", {}); out["npieces"] = r["sol"].get("npieces", 0)
    return out


def table(sysname, exp, untuned=("DET", "SAA_CVaR", "Moment_DRO", "Robust_DDU", "DD_CVaR"),
          tuned=("Exo_Winf", "Proposed"), main_tag="main", prefix="grid"):
    rows = {}
    for m in untuned:
        r = load(sysname, exp, main_tag, m)
        if r is not None:
            rows[m] = metrics(r)
    picks = {}
    for m in tuned:
        tag, grid = select(sysname, exp, m, prefix)
        picks[m] = (tag, grid)
        if tag:
            rows[m] = metrics(load(sysname, exp, tag, m))
    return rows, picks


if __name__ == "__main__":
    import sys
    sysname, exp = sys.argv[1], sys.argv[2]
    rows, picks = table(sysname, exp)
    for m, (tag, grid) in picks.items():
        print(f"{m}: picked {tag}")
        for g in grid:
            print(f"   eps {g['eps']:.3f}  valid joint {g['v_joint']:.3f} (net {g['v_net']:.3f}, res {g['v_res']:.3f})  total {g['v_total']:.1f}")
    print(f"{'method':11s} {'eps':>5s} {'econ':>8s} {'total':>8s}  {'p_net':>14s} {'p_res':>14s} {'p_joint':>14s} {'undel kWh':>16s} {'time':>6s} {'it':>3s} {'gap%':>5s}")
    for m, r in rows.items():
        f = lambda key: f"{100*r[key]:4.1f} [{100*r[key+'_ci'][0]:4.1f},{100*r[key+'_ci'][1]:4.1f}]"
        print(f"{m:11s} {r['eps']:5.3f} {r['econ']:8.1f} {r['total']:8.1f}  {f('net_fail'):>14s} {f('res_fail'):>14s} {f('joint_fail'):>14s} "
              f"{r['undel_kWh']:6.1f} [{r['undel_ci'][0]:4.1f},{r['undel_ci'][1]:4.1f}] {r['time_s']:6.0f} {r['iters']:3d} {100*r['gap']:5.2f}")


def mcnemar(fa, fb):
    """Exact two-sided McNemar test on paired binary failures (same test days)."""
    from math import comb
    b = int(np.sum(fa & ~fb)); c = int(np.sum(~fa & fb)); n = b + c
    if n == 0:
        return 1.0, b, c
    k = min(b, c)
    p = 2 * sum(comb(n, i) for i in range(k + 1)) / 2 ** n
    return min(1.0, p), b, c


def paired_vs(sysname, exp, ref_method="Proposed", **kw):
    """McNemar p-values of the system failure of every method against ref_method."""
    rows, picks = table(sysname, exp, **kw)
    files = {}
    for m in rows:
        tag = picks[m][0] if m in picks else kw.get("main_tag", "main")
        files[m] = load(sysname, exp, tag, m)
    ref = files[ref_method]["test_joint_fail"].astype(bool)
    out = {}
    for m, r in files.items():
        if m == ref_method:
            continue
        out[m] = mcnemar(r["test_joint_fail"].astype(bool), ref)
    return out


def latex_main(sysnames=("33", "123"), exp="fixed"):
    names = {"DET": "M1 DET", "SAA_CVaR": "M2 SAA-CVaR", "Moment_DRO": "M3 Moment-DRO", "Exo_Winf": "M4 Exo-W$_\\infty$",
             "Robust_DDU": "M5 Robust-DDU", "DD_CVaR": "M6 DD-CVaR", "Proposed": "M7 Proposed"}
    order = ["DET", "SAA_CVaR", "Moment_DRO", "Exo_Winf", "Robust_DDU", "DD_CVaR", "Proposed"]
    lines = []
    for sname in sysnames:
        rows, picks = table(sname, exp)
        pv = paired_vs(sname, exp)
        lines.append(f"\\multicolumn{{9}}{{@{{}}l}}{{\\emph{{IEEE {sname}-bus feeder}}}}\\\\")
        for m in order:
            if m not in rows:
                continue
            r = rows[m]
            ci = lambda k: f"{100*r[k]:.1f} [{100*r[k+'_ci'][0]:.1f}, {100*r[k+'_ci'][1]:.1f}]"
            p = pv.get(m, (None,))[0]
            ptxt = "--" if p is None else ("$<$0.001" if p < 1e-3 else f"{p:.3f}")
            eps = f"{r['eps']:.3f}" if m in ("Exo_Winf", "Proposed") else "--"
            lines.append(f"{names[m]} & {eps} & {r['econ']:.1f} & {r['total']:.1f} & {ci('net_fail')} & {ci('res_fail')} & "
                         f"{ci('joint_fail')} & {r['undel_kWh']:.1f} & {ptxt}\\\\")
        lines.append("\\midrule")
    return "\n".join(lines[:-1])
