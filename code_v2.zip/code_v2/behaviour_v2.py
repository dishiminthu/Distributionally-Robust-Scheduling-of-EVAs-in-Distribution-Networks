"""behaviour_v2.py -- what the price/behaviour dataset does and does not identify.

Data: Veeramsetty & Bharadwaj, "Electricity Price Dataset - EV Charging
Recommendation Dataset", Mendeley Data, doi:10.17632/wzkrczdbhs (file
EV_Charging_Strategy_Data.xlsx, 72,962 rows).  Documented labels of the
'Recommendation' column: 0 = G2V (charge), 1 = V2G (discharge to grid),
2 = battery discharging while the EV is away (driving).

Findings used in the revision (written to ../results_v2/behaviour_summary.json):
  * label 2 occurs exactly when the EV is unplugged now and next (Present = Next = 0);
  * label 1 (V2G) occurs only when the EV is plugged in now and next, and only
    when the price/mean ratio exceeds ~0.95-1.0;
  * among plugged-in rows the V2G share is 0 below the reference price and a
    flat ~49% above it.  The data therefore encode a threshold rule: they fix
    the DIRECTION of the response (higher price -> less G2V, more V2G) and its
    saturating shape, but not its strength for a real, heterogeneous fleet.
The response used in the case study is therefore a stated scenario (model_v2.prepare).
"""
import json
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
XLS = ROOT / "data" / "Electricity Price Dataset - EV Charging Recommendation Dataset" / "EV_Charging_Strategy_Data.xlsx"
OUT = Path(__file__).resolve().parents[1] / "results_v2"


def logit_fit(X, y, iters=100):
    b = np.zeros(X.shape[1])
    for _ in range(iters):
        p = np.clip(1 / (1 + np.exp(-X @ b)), 1e-9, 1 - 1e-9); W = p * (1 - p)
        bn = np.linalg.solve((X.T * W) @ X + 1e-8 * np.eye(X.shape[1]), (X.T * W) @ (X @ b + (y - p) / W))
        if np.max(np.abs(bn - b)) < 1e-10:
            return bn
        b = bn
    return b


def main():
    df = pd.read_excel(XLS); df.columns = ["pm", "soc", "pres", "nxt", "rec"]
    n = len(df)
    edges = [0, 0.6, 0.8, 0.9, 0.95, 1.0, 1.05, 1.1, 1.2, 1.4, 1.6, 6]
    df["bin"] = pd.cut(df.pm, edges)
    plug = df[df.pres == 1]
    share_all = pd.crosstab(df.bin, df.rec, normalize="index")
    share_plug = pd.crosstab(plug.bin, plug.rec, normalize="index")
    stay = plug[plug.nxt == 1]
    share_stay = pd.crosstab(stay.bin, stay.rec, normalize="index")
    lab2_unplugged = bool(((df.rec == 2) == ((df.pres == 0) & (df.nxt == 0))).all())
    v2g_only_plugged_staying = bool((df[df.rec == 1].pres.eq(1) & df[df.rec == 1].nxt.eq(1)).all())
    # net-propensity slope with the documented labels (what a naive logit would report)
    X = np.column_stack([np.ones(n), df.pm.values, df.soc.values])
    bg = logit_fit(X, (df.rec == 0).astype(float).values); bv = logit_fit(X, (df.rec == 1).astype(float).values)
    P = lambda b, p, s: 1 / (1 + np.exp(-(b[0] + b[1] * p + b[2] * s)))
    nu = lambda p: np.mean(P(bg, p, df.soc.values) - P(bv, p, df.soc.values))
    S_naive = -(nu(1 + 1e-4) - nu(1 - 1e-4)) / 2e-4
    mid = lambda iv: float(iv.mid) if iv.right < 6 else 1.8
    out = dict(
        n_rows=n, label2_iff_unplugged_now_and_next=lab2_unplugged, v2g_only_when_plugged_now_and_next=v2g_only_plugged_staying,
        bins=[mid(b) for b in share_plug.index],
        plugged_v2g_share=[float(x) for x in share_plug.get(1, pd.Series(0, index=share_plug.index)).values],
        plugged_g2v_share=[float(x) for x in share_plug.get(0, pd.Series(0, index=share_plug.index)).values],
        staying_v2g_share=[float(x) for x in share_stay.get(1, pd.Series(0, index=share_stay.index)).values],
        all_rows_share={str(k): [float(x) for x in share_all[k].values] for k in share_all.columns},
        naive_net_propensity_slope_documented_labels=float(S_naive),
        n_plugged=int(len(plug)), n_plugged_staying=int(len(stay)),
    )
    OUT.mkdir(exist_ok=True)
    json.dump(out, open(OUT / "behaviour_summary.json", "w"), indent=2)
    print(json.dumps({k: v for k, v in out.items() if k != "all_rows_share"}, indent=1))


if __name__ == "__main__":
    main()
