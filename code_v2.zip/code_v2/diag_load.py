import sys, numpy as np, model_v2 as M
npz = sys.argv[1]
for ls in map(float, sys.argv[2:]):
    c = M.prepare(npz, load_scale=ls); nd = M.net_data(c)
    K = len(c["eva_buses"]); xf = np.zeros((K, 24)); xf[:, c["W"]] = 0.5
    sol, log = M.solve(c, "DET", M.default_pars(threads=6), x_fixed=xf, log_fn=lambda s: None)
    ev = M.summarize(M.evaluate(c, sol, "test"))
    v = np.sqrt(sol["vsq"][1:])
    print(f"{npz} load x{ls:.3f} (peak {c['P_load'].sum(0).max():.2f} MW): nominal Vmin {v.min():.4f}  sec_slack {sol['sec_slack']:.4f} "
          f"DG {sol['pdg'].sum():.2f} MWh  econ {sol['econ']:.0f} | DET OOS p_net {ev['p_net']:.3f} p_res {ev['p_res']:.2f} "
          f"undel {ev['undel_kWh']:.0f} kWh  thermal {ev['thermal_any']}", flush=True)
