import sys, numpy as np, model_v2 as M, run_v2 as R
c = R.case_for(sys.argv[1]); nd = M.net_data(c); c["W"] = np.arange(24)
for meth, rho in [("DD_CVaR", 0.0), ("DD_CVaR", 10.0), ("Proposed", 0.0), ("SAA_CVaR", 0.0)]:
    pars = M.default_pars(threads=6, n_add=4, rho_inc=rho, eps=0.0)
    sol, log = M.solve(c, meth, pars, x_fixed=None, log_fn=lambda s: None)
    s = M.summarize(M.evaluate(c, sol, "test", nd))
    print(f"{meth:9s} rho={rho:4.1f}: econ {sol['econ']:.1f} | x mean by hour {np.round(sol['x'].mean(0),2).tolist()} "
          f"| p_net {s['p_net']:.3f} p_res {s['p_res']:.3f} p_joint {s['p_joint']:.3f} total {s['total']:.1f} t {log['time_s']:.0f}s", flush=True)
