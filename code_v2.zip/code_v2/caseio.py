"""
caseio.py -- shared I/O, LinDistFlow network mapping, and evaluation utilities
for the DD-Wasserstein DRCC EV scheduling case study.

Pure numpy (no solver). Used by ddrcc_model.py (build) and figures.py (plot/eval).
"""
import json
import numpy as np
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]          # project root (original data, read-only)
DATA = ROOT / "data"


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------
def load_case(npz_name="case_inputs.npz"):
    d = dict(np.load(DATA / npz_name, allow_pickle=True))
    for k in list(d):                       # unwrap 0-d arrays to scalars
        if d[k].ndim == 0:
            d[k] = d[k].item()
    return d


# ---------------------------------------------------------------------------
# Radial-network LinDistFlow sensitivities
# ---------------------------------------------------------------------------
def build_tree(branches, nbus, root=1):
    """Return parent[], children{}, and path_edges[bus] = set of (edge index)."""
    radj = {i: [] for i in range(1, nbus + 1)}
    edge = {}
    for e, (i, j, r, x) in enumerate(branches):
        i, j = int(i), int(j)
        radj[i].append((j, e)); radj[j].append((i, e))
        edge[e] = (i, j, r, x)
    parent = {root: None}; parent_edge = {root: None}; order = [root]
    seen = {root}; stack = [root]
    while stack:
        u = stack.pop()
        for v, e in radj[u]:
            if v not in seen:
                seen.add(v); parent[v] = u; parent_edge[v] = e
                order.append(v); stack.append(v)
    path_edges = {root: []}
    for v in order[1:]:
        path_edges[v] = path_edges[parent[v]] + [parent_edge[v]]
    return parent, parent_edge, path_edges, edge, order


def build_RX(branches, nbus, root=1):
    """LinDistFlow sensitivity matrices R,X (nbus+1 x nbus+1, 1-indexed).
    dV_i = 2 * sum_b ( R[i,b]*p_inj_b + X[i,b]*q_inj_b ),  p_inj = injection (gen +, load -).
    R[i,b] = sum of branch r over edges shared by root->i and root->b paths."""
    _, _, path_edges, edge, _ = build_tree(branches, nbus, root)
    R = np.zeros((nbus + 1, nbus + 1)); X = np.zeros((nbus + 1, nbus + 1))
    pe = {b: set(path_edges[b]) for b in range(1, nbus + 1)}
    for i in range(1, nbus + 1):
        for b in range(1, nbus + 1):
            common = pe[i] & pe[b]
            if common:
                R[i, b] = sum(edge[e][2] for e in common)
                X[i, b] = sum(edge[e][3] for e in common)
    return R, X


def downstream_sets(branches, nbus, root=1):
    """For each branch e=(i,j) return the set of buses downstream of j (incl. j)."""
    parent, parent_edge, _, edge, order = build_tree(branches, nbus, root)
    children = {u: [] for u in range(1, nbus + 1)}
    for v in order[1:]:
        children[parent[v]].append(v)
    def desc(u):
        out = {u}
        for c in children[u]:
            out |= desc(c)
        return out
    down = {}
    for e, (i, j, r, x) in enumerate(branches):
        i, j = int(i), int(j)
        child = j if parent.get(j) == i else i
        down[e] = desc(child)
    return down


# ---------------------------------------------------------------------------
# LinDistFlow evaluation (given nodal injections in MW/MVar, p.u. base SBASE)
# ---------------------------------------------------------------------------
def lindistflow(p_inj_MW, q_inj_MW, case, R=None, X=None):
    """p_inj_MW,q_inj_MW : (nbus+1,) net injection (gen - load) in MW (idx 0 unused).
    Returns V (p.u.), branch active flow P_ij (MW), per-branch loading |P|/limit."""
    nbus = case["nbus"]; SBASE = case["SBASE"]; v0 = case["v0"]
    branches = case["branches"]
    if R is None:
        R, X = build_RX(branches, nbus)
    p = p_inj_MW / SBASE; q = q_inj_MW / SBASE          # to p.u.
    v2 = v0**2 + 2.0 * (R[1:, 1:] @ p[1:] + X[1:, 1:] @ q[1:])
    V = np.sqrt(np.clip(v2, 1e-6, None))
    V = np.concatenate([[v0], V])
    down = downstream_sets(branches, nbus)
    Pflow = np.zeros(len(branches))
    for e in range(len(branches)):
        Pflow[e] = sum(p_inj_MW[b] for b in down[e]) * -1.0  # flow toward root = -net inj downstream
    loading = np.abs(Pflow / SBASE) / np.maximum(case["Smax_pu"], 1e-6)
    return V, Pflow, loading


def violations(V, loading, case):
    """Return dict of voltage/thermal violation magnitudes and flags."""
    Vmin, Vmax = case["Vmin"], case["Vmax"]
    vlo = np.maximum(Vmin - V[1:], 0); vhi = np.maximum(V[1:] - Vmax, 0)
    thr = np.maximum(loading - 1.0, 0)
    return dict(v_under=vlo, v_over=vhi, thermal=thr,
                v_viol=float((vlo + vhi).sum()), i_viol=float(thr.sum()),
                any=bool((vlo + vhi).max() > 1e-6 or thr.max() > 1e-6))


# ---------------------------------------------------------------------------
# TRUE endogenous response (logistic) -- used ONLY for out-of-sample realisation
# ---------------------------------------------------------------------------
def true_net_shift(case, pi, soc=0.55):
    """Realised net-charging shift (fraction of nominal availability) induced by
    price pi under the TRUE calibrated logistic response, RELATIVE to the
    reference pi0=1.  This is what blind/linearised schedules are judged against
    out-of-sample, exposing their modelling error (paper Sec. V).

    Returns delta(pi) such that effective availability = a*(1 + delta).
    delta(pi) = -(nu(pi) - nu(pi0)) normalised by nu(pi0) ... here we use the
    propensity DIFFERENCE directly as the availability modulation, matching the
    linear surrogate a_eff = a(1 - S (pi-pi0)) at first order."""
    bch = np.asarray(case["logit_ch"]); bdis = np.asarray(case["logit_dis"])

    def nu(p):
        Pch = 1.0 / (1.0 + np.exp(-(bch[0] + bch[1] * p + bch[2] * soc)))
        Pdis = 1.0 / (1.0 + np.exp(-(bdis[0] + bdis[1] * p + bdis[2] * soc)))
        return Pch - Pdis
    nu0 = nu(1.0)
    return (nu(pi) - nu0)            # negative for pi>1 (less net charging / more V2G)


def radial_tree(branches, nbus, root=1):
    """children{bus}->[(child, edge_idx)], parent_edge{bus}->edge_idx, BFS order.
    For the SOCP branch-flow (Baran-Wu) nodal balance in the model."""
    parent, parent_edge, _, edge, order = build_tree(branches, nbus, root)
    children = {u: [] for u in range(1, nbus + 1)}
    for v in order[1:]:
        children[parent[v]].append((v, parent_edge[v]))
    return children, parent, parent_edge, edge, order


if __name__ == "__main__":
    # numpy self-test of the network mapping on the base case (no solver needed)
    c = load_case()
    nb, T = c["nbus"], c["T"]
    R, X = build_RX(c["branches"], nb)
    # base injections at the peak hour: load only (no DER, no EV) -> worst undervoltage
    tpk = int(c["P_load"].sum(0).argmax())
    p = np.zeros(nb + 1); q = np.zeros(nb + 1)
    p[1:nb+1] = -c["P_load"][1:nb+1, tpk]; q[1:nb+1] = -c["Q_load"][1:nb+1, tpk]
    V, Pf, ld = lindistflow(p, q, c, R, X)
    print(f"[selftest] peak hour {tpk}: Vmin={V[1:].min():.4f} p.u. @bus{V[1:].argmin()+1}, "
          f"Vmax={V[1:].max():.4f}, max branch loading={ld.max():.3f}")
    print(f"[selftest] substation flow (feeder head) = {Pf[0]:.3f} MW, total load={c['P_load'][:,tpk].sum():.3f} MW")
