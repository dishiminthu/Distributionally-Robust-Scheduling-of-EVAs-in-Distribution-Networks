"""mech_v2.py -- where reserve failures come from: charging side (up band / baseline charging
above the realised charging capacity) or discharging side (down band / scheduled V2G beyond
the realised V2G capacity), and the share of the network failures that coincide with them."""
import json, sys
import numpy as np
import model_v2 as M, run_v2 as R, select_v2 as S

def split(sname, meth, tag, exp="fixed"):
    c = R.case_for(sname); sol = S.load(sname, exp, tag, meth)["sol"]
    x = sol["x"]; Pm = c["ev_Pmax"][None, :, None]; a = c["ev_avail"][None]
    ct, dt_ = M.true_factors(c, x, c["m_test"]); A = np.maximum(a + c["xi_ev_test"], 0)
    pb = (sol["pch"] - sol["pdis"])[None]
    up = np.maximum(pb + sol["rup"][None] - A * Pm * ct - M.TAU * Pm, 0)
    dn = np.maximum(-A * Pm * dt_ - (pb - sol["rdn"][None]) - M.TAU * Pm, 0)
    fu = (up > 1e-9).any((1, 2)); fd = (dn > 1e-9).any((1, 2))
    W = c["W"]
    return dict(fail_up=float(fu.mean()), fail_dn=float(fd.mean()),
                undel_up_kWh=float(1e3 * up.sum((1, 2)).mean()), undel_dn_kWh=float(1e3 * dn.sum((1, 2)).mean()),
                up_in_window=float(up[:, :, W].sum() / max(up.sum(), 1e-12)), dn_in_window=float(dn[:, :, W].sum() / max(dn.sum(), 1e-12)),
                sold_up_MWh=float(sol["rup"].sum()), sold_dn_MWh=float(sol["rdn"].sum()),
                sold_up_win=float(sol["rup"][:, W].sum()), sold_dn_win=float(sol["rdn"][:, W].sum()),
                v2g_win_MWh=float(sol["pdis"][:, W].sum()), ch_win_MWh=float(sol["pch"][:, W].sum()))

if __name__ == "__main__":
    out = {}
    for sname in ["33", "123"]:
        for meth, tag in [("SAA_CVaR", "main"), ("Robust_DDU", "main"), ("DD_CVaR", "main"),
                          ("Exo_Winf", "grideps0.050"), ("Proposed", "grideps0.000")]:
            d = split(sname, meth, tag); out[f"{sname}|{meth}"] = d
            print(sname, f"{meth:11s}", {k: round(v, 3) for k, v in d.items()})
    json.dump(out, open(S.RES / "mechanism.json", "w"), indent=1)
