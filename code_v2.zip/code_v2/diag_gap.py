import numpy as np, model_v2 as M
c = M.prepare("case_inputs.npz", load_scale=1.728, vband=0.03); nd = M.net_data(c)
xf = np.zeros((4, 24)); xf[:, c["W"]] = 0.5
sol, log = M.solve(c, "SAA_CVaR", M.default_pars(threads=8, time_limit=60), x_fixed=xf, log_fn=lambda s: None)
for split in ["train", "valid", "test"]:
    dV, rm, rp = M.net_atoms(c, nd, split, 0.0)
    RA = M.res_atoms(c, M.SPEC["SAA_CVaR"], M.default_pars(), xf); U, O, g_rel, g_ub = M.net_pieces(c, nd, sol, dV, rm, rp, RA)
    xr = M.xi_re(c, split)
    print(f"{split:5s}: master-style P(g>0) {np.mean(g_ub>1e-9):.3f}  CVaR {M.cvar(g_ub,0.1):+.5f}  | "
          f"PV err @12h mean {xr[:, :4, 11].sum(1).mean():+.3f} MW, share PV at zero {np.mean(np.isclose(xr[:, :4, 11], -c['PV_fc'][None,:,11])):.2f}; "
          f"WT err @11h mean {xr[:, 4:, 10].sum(1).mean():+.3f} std {xr[:, 4:, 10].sum(1).std():.3f}")
c["m_train"] = np.ones((300, 4)); c["xi_ev_train"] = c["xi_ev_train"]
ev = M.evaluate(c, sol, "train"); print("OOS-style on train (true response, m=1): p_net %.3f p_res %.3f" % (ev["net_fail"].mean(), ev["res_fail"].mean()))
ev = M.evaluate(c, sol, "test")
idx = np.where(ev["net_fail"])[0]
vm = ev["vmag"]; print("test fails:", len(idx), " mean vmag", vm[idx].mean() if len(idx) else 0)
