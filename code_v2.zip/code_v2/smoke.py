import sys, time, numpy as np
import model_v2 as M
c = M.prepare("case_inputs.npz")
xf = np.zeros((4, 24)); xf[:, c["W"]] = 0.5
for meth in sys.argv[1:]:
    pars = M.default_pars(eps=0.05, threads=6)
    sol, log = M.solve(c, meth, pars, x_fixed=xf)
    ev = M.summarize(M.evaluate(c, sol, "test"))
    print(meth, {k: (round(v, 4) if isinstance(v, float) else v) for k, v in ev.items()},
          "econ", round(sol["econ"], 1), "time", round(log["time_s"], 1), "stats", sol["stats"])
