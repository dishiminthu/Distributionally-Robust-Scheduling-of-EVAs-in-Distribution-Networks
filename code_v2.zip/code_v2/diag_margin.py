import numpy as np, model_v2 as M
for npz in ["case_inputs.npz", "case_inputs_123.npz"]:
    c = M.prepare(npz); nd = M.net_data(c)
    K = len(c["eva_buses"]); xf = np.zeros((K, 24)); xf[:, c["W"]] = 0.5
    sol, log = M.solve(c, "DET", M.default_pars(threads=6), x_fixed=xf, log_fn=lambda s: None)
    v = np.sqrt(sol["vsq"][1:]); print(f"== {npz}: nominal V min {v.min():.4f} (bus {v.min(1).argmin()+1}, hour {v.min(0).argmin()+1}), V max {v.max():.4f}")
    print("   hourly min V:", np.round(v.min(0), 3))
    dV, _, _ = M.net_atoms(c, nd, "test", 0.0)
    vr = np.sqrt(np.clip(sol["vsq"][1:][None] + dV, 0, None))
    print(f"   OOS (renewables only, no EV recourse): min V {vr.min():.4f}, max V {vr.max():.4f}; "
          f"5% quantile of daily min V {np.quantile(vr.min((1,2)), 0.05):.4f}")
    print("   EV schedule pch-pdis (MW) by EVA in window:\n", np.round((sol['pch']-sol['pdis'])[:, c['W']], 3))
    print("   rup/rdn sums:", sol["rup"].sum().round(2), sol["rdn"].sum().round(2), " DG:", sol["pdg"].sum().round(3))
